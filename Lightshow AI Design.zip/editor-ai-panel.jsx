// AI Actions panel — slides in from the right, with visible loading states.

const AIPanel = ({ onClose, scoped = false }) => {
  const [running, setRunning] = React.useState(null);
  const [progress, setProgress] = React.useState(0);
  const [step, setStep] = React.useState(0);
  const [style, setStyle] = React.useState('classic');
  const [lastResult, setLastResult] = React.useState(null);

  const styles = [
    { id: 'classic', name: 'Classic Christmas', desc: 'Warm whites, reds, greens. Steady twinkles, gentle fades.', icon: <I.Snow size={16}/> },
    { id: 'high',    name: 'High Energy',       desc: 'Strobe, chase, fireworks. Hits every kick and snare.',     icon: <I.Zap size={16}/> },
    { id: 'calm',    name: 'Calm & Elegant',    desc: 'Soft fades, color washes, no strobes. Sky-blue palette.',  icon: <I.Wave size={16}/> },
  ];

  const aiSteps = {
    'analyze':  ['Decoding audio…', 'Detecting tempo & beats…', 'Finding sections…', 'Tagging energy levels…'],
    'generate': ['Reading layout…', 'Mapping fixtures to instruments…', 'Sequencing kick → roofline…', 'Sequencing leads → mega tree…', 'Polishing transitions…'],
    'refine':   ['Realigning to beat grid…', 'Smoothing crossfades…', 'Tightening edges…'],
    'palette':  ['Sampling key & mood…', 'Building 5-color palette…', 'Assigning to fixtures…'],
  };

  const run = (which) => {
    setRunning(which);
    setProgress(0);
    setStep(0);
    setLastResult(null);
    const steps = aiSteps[which];
    const total = steps.length;
    const per = which === 'generate' ? 700 : 500;
    let s = 0;
    const tick = () => {
      s += 1;
      setStep(s);
      setProgress(Math.min(100, Math.round((s / total) * 100)));
      if (s < total) setTimeout(tick, per);
      else setTimeout(() => {
        setRunning(null);
        setLastResult({
          which,
          summary:
            which === 'generate' ? '38 effect blocks placed across 6 tracks · matches 92% of detected beats.' :
            which === 'analyze' ? 'Tempo 140 BPM · 421 beats · 6 sections detected (intro, build, drop ×2, breakdown, outro).' :
            which === 'refine'   ? '14 blocks nudged · all transitions snapped to nearest beat.' :
            'Palette generated: deep navy, sky, warm white, candle gold, soft red.',
        });
      }, 400);
    };
    setTimeout(tick, 380);
  };

  return (
    <div style={{ position: scoped ? 'absolute' : 'fixed', top: 0, right: 0, bottom: 0, width: 380, background: 'var(--surface)',
      borderLeft: '1px solid var(--line)', boxShadow: '-12px 0 36px rgba(20,22,28,.08)',
      display: 'flex', flexDirection: 'column', zIndex: 50 }} className="fade-in">
      <div style={{ height: 52, display: 'flex', alignItems: 'center', padding: '0 16px',
        borderBottom: '1px solid var(--line)' }}>
        <div style={{ width: 26, height: 26, borderRadius: 7, background: 'var(--accent)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 10,
          boxShadow: '0 0 0 4px var(--accent-50)' }}><I.Sparkles size={13}/></div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.1 }}>AI Actions</div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>One click. No prompts.</div>
        </div>
        <div style={{ flex: 1 }}/>
        <button className="btn ghost sm" onClick={onClose} style={{ padding: 0, width: 28, height: 28 }}>
          <I.X size={14}/>
        </button>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '12px 16px 16px' }}>
        {/* Generate Sequence — primary action */}
        <div style={{ background: 'var(--accent-50)', border: '1px solid var(--accent-200)', borderRadius: 10, padding: 14, marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <I.Wand size={14} style={{ color: 'var(--accent-700)' }}/>
            <div style={{ fontWeight: 600, fontSize: 13 }}>Generate sequence</div>
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)', marginBottom: 10 }}>
            Lumen will sequence all your fixtures to match the song.
          </div>

          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.04, textTransform: 'uppercase',
            color: 'var(--ink-3)', marginBottom: 6 }}>Style</div>
          <div style={{ display: 'grid', gap: 4, marginBottom: 12 }}>
            {styles.map(s => (
              <button key={s.id} onClick={() => setStyle(s.id)} className="btn"
                style={{ height: 'auto', padding: 10, justifyContent: 'flex-start', textAlign: 'left',
                  borderColor: style === s.id ? 'var(--accent)' : 'var(--line)',
                  background: style === s.id ? 'var(--surface)' : 'var(--surface)',
                  boxShadow: style === s.id ? '0 0 0 3px var(--accent-100)' : 'none' }}>
                <div style={{ width: 28, height: 28, borderRadius: 6, background: 'var(--accent-100)',
                  color: 'var(--accent-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 10, flexShrink: 0 }}>
                  {s.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 12.5 }}>{s.name}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginTop: 1, fontWeight: 400 }}>{s.desc}</div>
                </div>
                {style === s.id && <I.Check size={14} style={{ color: 'var(--accent)' }}/>}
              </button>
            ))}
          </div>

          <button className="btn primary" onClick={() => run('generate')} disabled={!!running}
            style={{ width: '100%', justifyContent: 'center', height: 38, fontSize: 13.5,
              opacity: running === 'generate' ? 0.95 : 1, position: 'relative', overflow: 'hidden' }}>
            {running === 'generate' ? (
              <>
                <I.Loader size={14} className="spin"/>
                <span>{aiSteps.generate[Math.min(step, aiSteps.generate.length-1)]}</span>
                <div style={{ position: 'absolute', left: 0, bottom: 0, height: 3, width: `${progress}%`,
                  background: '#fff', opacity: 0.6, transition: 'width .25s' }}/>
              </>
            ) : (
              <><I.Sparkles size={14}/> Generate sequence</>
            )}
          </button>
        </div>

        {/* Other actions */}
        <div style={{ display: 'grid', gap: 8 }}>
          {[
            { id: 'analyze', icon: <I.Wave size={14}/>, label: 'Analyze audio', desc: 'Detect tempo, beats, sections, mood.' },
            { id: 'refine', icon: <I.Zap size={14}/>, label: 'Refine timing',   desc: 'Snap & smooth existing effects.' },
            { id: 'palette', icon: <I.Eyedrop size={14}/>, label: 'Generate palette', desc: '5 colors derived from the song.' },
          ].map(a => (
            <div key={a.id} style={{ border: '1px solid var(--line)', borderRadius: 10,
              padding: 12, background: 'var(--surface)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 30, height: 30, borderRadius: 6, background: 'var(--panel)',
                  color: 'var(--ink-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{a.icon}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{a.label}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{a.desc}</div>
                </div>
                <button onClick={() => run(a.id)} disabled={!!running} className="btn sm"
                  style={{ minWidth: 76, justifyContent: 'center',
                    background: running === a.id ? 'var(--accent-50)' : 'var(--surface)',
                    borderColor: running === a.id ? 'var(--accent-200)' : 'var(--line)' }}>
                  {running === a.id ? <><I.Loader size={12} className="spin"/> {progress}%</> : 'Run'}
                </button>
              </div>
              {running === a.id && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ height: 4, background: 'var(--panel)', borderRadius: 2, overflow: 'hidden' }}>
                    <div style={{ width: `${progress}%`, height: '100%', background: 'var(--accent)', transition: 'width .25s' }}/>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>
                    {aiSteps[a.id][Math.min(step, aiSteps[a.id].length-1)]}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* result strip */}
        {lastResult && (
          <div className="fade-in" style={{ marginTop: 14, padding: 12, background: 'var(--accent-50)',
            border: '1px solid var(--accent-200)', borderRadius: 10 }}>
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
              <I.Check size={14} style={{ color: 'var(--accent-700)', marginTop: 2 }}/>
              <div style={{ flex: 1, fontSize: 12.5 }}>
                <div style={{ fontWeight: 600, marginBottom: 2, color: 'var(--accent-ink)' }}>
                  {lastResult.which === 'generate' ? 'Sequence generated' :
                   lastResult.which === 'analyze' ? 'Audio analyzed' :
                   lastResult.which === 'refine' ? 'Timing refined' : 'Palette generated'}
                </div>
                <div style={{ color: 'var(--ink-2)' }}>{lastResult.summary}</div>
                <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
                  <button className="btn sm" style={{ height: 26 }}>Undo</button>
                  <button className="btn sm" style={{ height: 26 }}>See changes</button>
                </div>
              </div>
            </div>
          </div>
        )}

        <div style={{ marginTop: 18, padding: 12, background: 'var(--panel)', borderRadius: 8, fontSize: 11.5, color: 'var(--ink-3)' }}>
          <strong style={{ color: 'var(--ink-2)' }}>Tip:</strong> Generate places a starting sequence. You can always
          edit individual blocks afterwards on the timeline — AI is a draft, not the final word.
        </div>
      </div>
    </div>
  );
};

window.AIPanel = AIPanel;
