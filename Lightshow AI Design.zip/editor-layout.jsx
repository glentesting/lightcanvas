// Layout tab — house illustration + fixture drawing tools + fixture list

const LayoutTab = ({ annotations, mode, setMode }) => {
  const [tool, setTool] = React.useState('select');
  const [selected, setSelected] = React.useState('roofline');
  const [snap, setSnap] = React.useState(true);

  const tools = [
    { id: 'select', icon: <I.Cursor size={14}/>, label: 'Select', sk: 'V' },
    { id: 'pen',    icon: <I.Pen size={14}/>,    label: 'Draw fixture', sk: 'P' },
    { id: 'rect',   icon: <I.Layout size={14}/>, label: 'Rectangle', sk: 'R' },
    { id: 'circle', icon: <I.Bulb size={14}/>,   label: 'Tree / circle', sk: 'C' },
  ];

  return (
    <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
      {/* canvas */}
      <div style={{ flex: 1, position: 'relative', background:
        'linear-gradient(135deg, #f7f6f2, #ecebe6)', overflow: 'hidden' }}>
        {/* tool strip */}
        <div style={{ position: 'absolute', top: 14, left: '50%', transform: 'translateX(-50%)',
          background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 10,
          padding: 4, display: 'flex', gap: 2, boxShadow: 'var(--shadow)', zIndex: 10 }}>
          {tools.map(t => (
            <button key={t.id} onClick={() => setTool(t.id)} title={`${t.label} (${t.sk})`}
              className="btn ghost sm" style={{ width: 32, height: 30, padding: 0,
              background: tool === t.id ? 'var(--accent-50)' : 'transparent',
              color: tool === t.id ? 'var(--accent-ink)' : 'var(--ink-2)' }}>
              {t.icon}
            </button>
          ))}
          <div style={{ width: 1, background: 'var(--line)', margin: '4px 4px' }}/>
          <button className="btn ghost sm" onClick={() => setSnap(s => !s)} title="Snap to grid"
            style={{ width: 32, height: 30, padding: 0,
              background: snap ? 'var(--accent-50)' : 'transparent',
              color: snap ? 'var(--accent-ink)' : 'var(--ink-2)' }}>
            <I.Grid size={14}/>
          </button>
        </div>

        {/* mode toggle (freeform vs grid) */}
        <div style={{ position: 'absolute', top: 14, left: 14, display: 'flex', background: 'var(--surface)',
          border: '1px solid var(--line)', borderRadius: 8, padding: 3, boxShadow: 'var(--shadow-sm)', zIndex: 10 }}>
          {['Freeform', 'Grid snap'].map((m, i) => (
            <button key={m} onClick={() => setMode(i === 0 ? 'freeform' : 'grid')}
              className="btn ghost sm" style={{ height: 26, padding: '0 10px', borderRadius: 5, fontSize: 12,
              background: (mode === 'freeform' && i === 0) || (mode === 'grid' && i === 1) ? 'var(--panel)' : 'transparent',
              fontWeight: ((mode === 'freeform' && i === 0) || (mode === 'grid' && i === 1)) ? 600 : 500 }}>
              {m}
            </button>
          ))}
        </div>

        {/* zoom indicator */}
        <div style={{ position: 'absolute', bottom: 14, right: 14, display: 'flex', gap: 4, alignItems: 'center',
          background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 8, padding: 4, boxShadow: 'var(--shadow-sm)' }}>
          <button className="btn ghost sm" style={{ width: 24, height: 24, padding: 0 }}>−</button>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-2)', padding: '0 6px',
            fontVariantNumeric: 'tabular-nums', minWidth: 38, textAlign: 'center' }}>100%</div>
          <button className="btn ghost sm" style={{ width: 24, height: 24, padding: 0 }}>+</button>
        </div>

        {/* canvas content */}
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ position: 'relative', boxShadow: '0 8px 40px rgba(20,22,28,.15)', borderRadius: 6, overflow: 'hidden' }}>
            {/* dark photo (illustrated house) */}
            <House width={720} height={420} lights={null}/>
            {/* fixture overlays — colored highlights showing what's been drawn */}
            <svg width="720" height="420" viewBox="0 0 720 420"
              style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
              {/* roofline overlay */}
              <path d="M170 200 L360 110 L550 200 M70 240 L140 195 L210 240 M510 240 L580 195 L650 240"
                fill="none" stroke="oklch(70% 0.16 var(--accent-h))" strokeWidth="3" strokeOpacity={selected==='roofline' ? 0.95 : 0.55} strokeDasharray={selected==='roofline' ? '0' : '4 4'}/>
              {/* window outlines */}
              {[[220,230],[460,230],[105,260],[545,260]].map(([x,y],i) => (
                <rect key={i} x={x-1} y={y-1} width="42" height="52" fill="none"
                  stroke="oklch(78% 0.16 90)" strokeWidth="2.2" strokeOpacity={selected==='windows' ? 0.95 : 0.55}/>
              ))}
              {/* bushes */}
              {[[230,320,28,14],[290,322,22,12],[480,320,30,14]].map(([cx,cy,rx,ry],i)=>(
                <ellipse key={i} cx={cx} cy={cy} rx={rx+2} ry={ry+2} fill="none"
                  stroke="oklch(58% 0.13 145)" strokeWidth="2" strokeOpacity={selected==='bushes' ? 0.95 : 0.55}/>
              ))}
              {/* arches */}
              {[0,1,2].map(i => (
                <path key={i} d={`M${310+i*8} 320 Q ${360} ${270-i*5} ${410-i*8} 320`}
                  fill="none" stroke="oklch(72% 0.13 170)" strokeWidth="2.2" strokeOpacity={selected==='arches' ? 0.95 : 0.55}/>
              ))}
              {/* mega tree */}
              <ellipse cx="690" cy="250" rx="32" ry="80" fill="none" stroke="oklch(60% 0.18 280)" strokeWidth="2.2" strokeOpacity={selected==='megaTree' ? 0.95 : 0.55}/>
              {/* mini trees */}
              {[[310,295],[410,295]].map(([x,y],i) => (
                <polygon key={i} points={`${x},${y-30} ${x-22},${y+30} ${x+22},${y+30}`}
                  fill="none" stroke="oklch(58% 0.13 145)" strokeWidth="2" strokeOpacity={selected==='miniTrees' ? 0.95 : 0.55}/>
              ))}
              {/* grid overlay */}
              {mode === 'grid' && Array.from({length: 18}).map((_, i) => (
                <line key={`gv${i}`} x1={i*40} y1="0" x2={i*40} y2="420" stroke="rgba(255,255,255,.07)" strokeWidth="1"/>
              ))}
              {mode === 'grid' && Array.from({length: 11}).map((_, i) => (
                <line key={`gh${i}`} x1="0" y1={i*40} x2="720" y2={i*40} stroke="rgba(255,255,255,.07)" strokeWidth="1"/>
              ))}
            </svg>

            {/* selection handles for currently selected */}
            {selected === 'roofline' && (
              <>
                {[[170,200],[360,110],[550,200]].map(([x,y],i)=>(
                  <div key={i} style={{ position: 'absolute', left: x-5, top: y-5, width: 10, height: 10,
                    background: '#fff', border: '2px solid var(--accent)', borderRadius: 2 }}/>
                ))}
              </>
            )}
          </div>
        </div>

        {annotations && (
          <span className="pin" style={{ top: 80, left: 220 }}>3
            <span className="tip">Toggle freeform (draw on a photo) or grid (snap-to-grid for beginners). Both work; pick what fits.</span>
          </span>
        )}
      </div>

      {/* right panel — fixture list */}
      <div style={{ width: 260, borderLeft: '1px solid var(--line)', background: 'var(--surface)',
        display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        <div style={{ padding: '14px 16px 10px', borderBottom: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <div style={{ fontWeight: 600, fontSize: 13 }}>Fixtures</div>
            <span className="chip muted">6 · 988 px</span>
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>Click to select. Drag to reorder.</div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', padding: 8 }}>
          {FIXTURES.map(f => (
            <div key={f.id} onClick={() => setSelected(f.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px',
                borderRadius: 7, cursor: 'pointer', marginBottom: 2,
                background: selected === f.id ? 'var(--accent-50)' : 'transparent',
                border: selected === f.id ? '1px solid var(--accent-200)' : '1px solid transparent' }}>
              <I.Drag size={12} style={{ color: 'var(--ink-4)' }}/>
              <div style={{ width: 24, height: 24, borderRadius: 5,
                background: selected === f.id ? 'var(--accent)' : 'var(--accent-50)',
                color: selected === f.id ? '#fff' : 'var(--accent-ink)',
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{f.icon}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{f.name}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-4)' }}>{f.count} {f.count > 1 ? 'instances' : 'instance'} · {f.pixels * f.count} px</div>
              </div>
              <button className="btn ghost sm" style={{ padding: 0, width: 22, height: 22 }} onClick={e => e.stopPropagation()}>
                <I.More size={12}/>
              </button>
            </div>
          ))}
          <button className="btn sm" style={{ width: '100%', marginTop: 8, justifyContent: 'center' }}>
            <I.Plus size={13}/> Add fixture
          </button>
        </div>
        {/* properties */}
        <div style={{ borderTop: '1px solid var(--line)', padding: 14, background: 'var(--panel)' }}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.06, textTransform: 'uppercase',
            color: 'var(--ink-3)', marginBottom: 10 }}>Properties</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 4 }}>Pixels</div>
              <input defaultValue="220" style={{ width: '100%', height: 28, border: '1px solid var(--line)',
                borderRadius: 5, padding: '0 8px', fontSize: 12, background: 'var(--surface)', outline: 'none', fontVariantNumeric: 'tabular-nums' }}/>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 4 }}>Universe</div>
              <input defaultValue="1" style={{ width: '100%', height: 28, border: '1px solid var(--line)',
                borderRadius: 5, padding: '0 8px', fontSize: 12, background: 'var(--surface)', outline: 'none', fontVariantNumeric: 'tabular-nums' }}/>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 4 }}>Start ch.</div>
              <input defaultValue="1" style={{ width: '100%', height: 28, border: '1px solid var(--line)',
                borderRadius: 5, padding: '0 8px', fontSize: 12, background: 'var(--surface)', outline: 'none', fontVariantNumeric: 'tabular-nums' }}/>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', marginBottom: 4 }}>Direction</div>
              <select style={{ width: '100%', height: 28, border: '1px solid var(--line)',
                borderRadius: 5, padding: '0 6px', fontSize: 12, background: 'var(--surface)', outline: 'none' }}>
                <option>L → R</option><option>R → L</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

window.LayoutTab = LayoutTab;
