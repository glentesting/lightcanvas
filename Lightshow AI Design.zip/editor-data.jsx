// Editor — main app screen with tabs (Audio Timeline, Layout, Preview).
// AI Actions panel slides in from the right. Variations of layout are
// controlled by the `variant` prop: 'default' | 'rail' | 'dense'.

const EFFECTS = [
  { id: 'twinkle',  name: 'Twinkle',     color: 'var(--fx-twinkle)' },
  { id: 'chase',    name: 'Chase',       color: 'var(--fx-chase)' },
  { id: 'fade',     name: 'Fade',        color: 'var(--fx-fade)' },
  { id: 'strobe',   name: 'Strobe',      color: 'var(--fx-strobe)' },
  { id: 'sparkle',  name: 'Sparkle',     color: 'var(--fx-sparkle)' },
  { id: 'wave',     name: 'Wave',        color: 'var(--fx-wave)' },
  { id: 'pulse',    name: 'Pulse',       color: 'var(--fx-pulse)' },
  { id: 'wash',     name: 'Color Wash',  color: 'var(--fx-wash)' },
  { id: 'meteor',   name: 'Meteor',      color: 'var(--fx-meteor)' },
  { id: 'firework', name: 'Fireworks',   color: 'var(--fx-firework)' },
];

const FIXTURES = [
  { id: 'roofline',  name: 'Roofline strip', shortcut: 'R', icon: <I.House size={14}/>, count: 1, pixels: 220 },
  { id: 'windows',   name: 'Window outline', shortcut: 'W', icon: <I.Layout size={14}/>, count: 4, pixels: 32 },
  { id: 'bushes',    name: 'Bush wraps',     shortcut: 'B', icon: <I.Bulb size={14}/>, count: 3, pixels: 60 },
  { id: 'megaTree',  name: 'Mega tree',      shortcut: 'M', icon: <I.Tree size={14}/>, count: 1, pixels: 480 },
  { id: 'miniTrees', name: 'Mini tree',      shortcut: 'T', icon: <I.Tree size={14}/>, count: 2, pixels: 50 },
  { id: 'arches',    name: 'Arches',         shortcut: 'A', icon: <I.Wave size={14}/>, count: 3, pixels: 50 },
];

// Track structure for the timeline. Order matters — top to bottom.
const TRACKS = [
  { id: 'roofline',  name: 'Roofline strip', count: '220 px' },
  { id: 'megaTree',  name: 'Mega tree',      count: '480 px' },
  { id: 'arches',    name: 'Arches (×3)',    count: '150 px' },
  { id: 'windows',   name: 'Windows (×4)',   count: '128 px' },
  { id: 'bushes',    name: 'Bushes (×3)',    count: '180 px' },
  { id: 'miniTrees', name: 'Mini trees (×2)',count: '100 px' },
];

// Pre-sequenced effects for "Wizards in Winter" — first 30 seconds.
// time/dur in seconds.
const SEQ = [
  { track: 'roofline', t: 0,    d: 4,    fx: 'fade' },
  { track: 'roofline', t: 4,    d: 0.6,  fx: 'strobe' },
  { track: 'roofline', t: 5,    d: 0.6,  fx: 'strobe' },
  { track: 'roofline', t: 6,    d: 6,    fx: 'chase' },
  { track: 'roofline', t: 12.5, d: 4,    fx: 'wave' },
  { track: 'roofline', t: 17,   d: 3,    fx: 'wash' },
  { track: 'roofline', t: 20.5, d: 2.5,  fx: 'twinkle' },
  { track: 'roofline', t: 23.5, d: 6.5,  fx: 'chase' },

  { track: 'megaTree', t: 1,    d: 3,    fx: 'twinkle' },
  { track: 'megaTree', t: 5,    d: 7,    fx: 'firework' },
  { track: 'megaTree', t: 12.5, d: 4,    fx: 'pulse' },
  { track: 'megaTree', t: 17,   d: 4,    fx: 'meteor' },
  { track: 'megaTree', t: 21.5, d: 8.5,  fx: 'firework' },

  { track: 'arches',   t: 0,    d: 5,    fx: 'sparkle' },
  { track: 'arches',   t: 5.5,  d: 2,    fx: 'chase' },
  { track: 'arches',   t: 8,    d: 4,    fx: 'wave' },
  { track: 'arches',   t: 12.5, d: 4,    fx: 'pulse' },
  { track: 'arches',   t: 17,   d: 6,    fx: 'chase' },
  { track: 'arches',   t: 23.5, d: 6.5,  fx: 'wave' },

  { track: 'windows',  t: 0,    d: 12,   fx: 'fade' },
  { track: 'windows',  t: 12.5, d: 4.5,  fx: 'twinkle' },
  { track: 'windows',  t: 17,   d: 13,   fx: 'fade' },

  { track: 'bushes',   t: 2,    d: 2,    fx: 'sparkle' },
  { track: 'bushes',   t: 5,    d: 7,    fx: 'twinkle' },
  { track: 'bushes',   t: 12.5, d: 4,    fx: 'wash' },
  { track: 'bushes',   t: 17,   d: 6,    fx: 'sparkle' },
  { track: 'bushes',   t: 23.5, d: 6.5,  fx: 'twinkle' },

  { track: 'miniTrees',t: 0,    d: 5,    fx: 'twinkle' },
  { track: 'miniTrees',t: 6,    d: 6,    fx: 'sparkle' },
  { track: 'miniTrees',t: 12.5, d: 4,    fx: 'pulse' },
  { track: 'miniTrees',t: 17,   d: 13,   fx: 'twinkle' },
];

// Synthesize a "waveform" for the demo song — deterministic per index.
const WAVE = Array.from({ length: 600 }, (_, i) => {
  const t = i / 600 * 30;
  const env = 0.4 + 0.6 * Math.min(1, t/3) * (1 - Math.max(0, (t-25)/5));
  const beat = 0.4 * Math.abs(Math.sin(t * Math.PI * 140/60));
  const swell = 0.3 * Math.sin(t * 0.4) + 0.3 * Math.cos(t * 1.3 + 0.5);
  const noise = ((Math.sin(i*1.31) * 9301 + 49297) % 233280)/233280 * 0.4 - 0.2;
  return Math.max(0.04, Math.min(1, env * (0.4 + beat + swell*0.3 + noise*0.2)));
});

// Beats every 60/140 = 0.428s
const BEATS = Array.from({length: 70}, (_, i) => i * (60/140));
// Downbeats every 4 beats
const DOWNBEATS = BEATS.filter((_, i) => i % 4 === 0);

window.EFFECTS = EFFECTS;
window.FIXTURES = FIXTURES;
window.TRACKS = TRACKS;
window.SEQ = SEQ;
window.WAVE = WAVE;
window.BEATS = BEATS;
window.DOWNBEATS = DOWNBEATS;
