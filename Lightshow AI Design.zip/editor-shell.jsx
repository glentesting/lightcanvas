// Editor — main app screen.
// Variants:
//   'default' — left vertical sidebar with sections, comfy timeline
//   'rail'    — narrow icon rail + popover panels, comfy timeline
//   'dense'   — left sidebar collapsed labels, dense compact timeline

const TopBar = ({ projectName, onBack, onExport, onAI, dirty }) => (
  <div style={{ height: 52, borderBottom: '1px solid var(--line)', background: 'var(--surface)',
    display: 'flex', alignItems: 'center', padding: '0 14px', gap: 12, flexShrink: 0, position: 'relative', zIndex: 30 }}>
    <button className="btn ghost sm" onClick={onBack} title="Back to dashboard">
      <I.ChevL size={14}/>
    </button>
    <div style={{ width: 1, height: 22, background: 'var(--line)' }}/>
    <Logo size={18} withText={false}/>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ fontSize: 13, color: 'var(--ink-3)' }}>My shows /</span>
      <span style={{ fontWeight: 600, fontSize: 14 }}>{projectName}</span>
      <button className="btn ghost sm" style={{ padding: '0 6px' }}><I.Pencil size={12}/></button>
      {dirty && <span style={{ fontSize: 11, color: 'var(--ink-4)', marginLeft: 4 }}>· unsaved</span>}
    </div>
    <div style={{ flex: 1 }}/>
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px',
      background: 'var(--panel)', borderRadius: 6, fontSize: 12, color: 'var(--ink-3)' }}>
      <I.Music size={13}/> Wizards in Winter <span style={{ color: 'var(--ink-4)' }}>· 3:04</span>
    </div>
    <button className="btn sm" onClick={onAI}>
      <I.Sparkles size={14}/> AI Actions
      <span className="kbd" style={{ marginLeft: 2 }}>⌘K</span>
    </button>
    <button className="btn sm"><I.Save size={14}/> Save</button>
    <button className="btn primary sm" onClick={onExport}><I.Export size={14}/> Export</button>
  </div>
);

// ─── Left sidebar — full version (default + dense variants) ────────────
const SidebarSection = ({ title, children, defaultOpen = true, compact }) => {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div style={{ borderBottom: '1px solid var(--line)' }}>
      <button onClick={() => setOpen(!open)} style={{ width: '100%', display: 'flex',
        alignItems: 'center', gap: 6, padding: compact ? '8px 12px' : '10px 14px',
        background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left',
        fontSize: 11, fontWeight: 600, letterSpacing: 0.06, textTransform: 'uppercase',
        color: 'var(--ink-3)' }}>
        <I.ChevD size={11} style={{ transform: open ? 'rotate(0)' : 'rotate(-90deg)', transition: 'transform .15s' }}/>
        {title}
      </button>
      {open && <div style={{ padding: compact ? '0 8px 8px' : '0 10px 10px' }}>{children}</div>}
    </div>
  );
};

const LeftSidebar = ({ onAI, activeTab, compact }) => (
  <div style={{ width: compact ? 220 : 240, borderRight: '1px solid var(--line)', background: 'var(--surface)',
    display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'hidden' }}>
    <div style={{ overflowY: 'auto', flex: 1 }}>
      <SidebarSection title="Song Upload" compact={compact}>
        <div style={{ background: 'var(--panel)', border: '1px solid var(--line)', borderRadius: 8,
          padding: 10, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 6, background:
            'linear-gradient(135deg, oklch(60% 0.18 250), oklch(72% 0.13 200))',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
            <I.Music size={16}/>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 600, fontSize: 12.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              Wizards in Winter
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>140 BPM · D minor</div>
          </div>
        </div>
        <button className="btn sm" style={{ width: '100%', marginTop: 8, justifyContent: 'center' }}>
          <I.Upload size={13}/> Replace song
        </button>
      </SidebarSection>

      <SidebarSection title="Layout" compact={compact}>
        <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 8 }}>6 fixtures · 988 pixels</div>
        {FIXTURES.map(f => (
          <div key={f.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 6px',
            borderRadius: 5, fontSize: 12.5, cursor: 'default' }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--panel)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <div style={{ width: 18, height: 18, borderRadius: 4, background: 'var(--accent-50)',
              color: 'var(--accent-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{f.icon}</div>
            <span style={{ flex: 1 }}>{f.name}</span>
            <span style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>×{f.count}</span>
          </div>
        ))}
      </SidebarSection>

      <SidebarSection title="Sequence" compact={compact}>
        <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 8 }}>Drag onto a track</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
          {EFFECTS.map(fx => (
            <div key={fx.id} draggable style={{ padding: '6px 8px', borderRadius: 5,
              border: '1px solid var(--line)', background: 'var(--surface)',
              fontSize: 11.5, fontWeight: 500, cursor: 'grab', display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: fx.color, flexShrink: 0 }}/>
              <span style={{ overflow:'hidden', textOverflow: 'ellipsis', whiteSpace:'nowrap' }}>{fx.name}</span>
            </div>
          ))}
        </div>
      </SidebarSection>

      <SidebarSection title="AI Actions" compact={compact}>
        <button className="btn primary sm" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 6 }} onClick={onAI}>
          <I.Sparkles size={13}/> Generate sequence
        </button>
        <button className="btn sm" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 6 }} onClick={onAI}>
          <I.Wave size={13}/> Analyze audio
        </button>
        <button className="btn sm" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 6 }} onClick={onAI}>
          <I.Zap size={13}/> Refine timing
        </button>
        <button className="btn sm" style={{ width: '100%', justifyContent: 'flex-start' }} onClick={onAI}>
          <I.Eyedrop size={13}/> Generate palette
        </button>
      </SidebarSection>
    </div>
  </div>
);

// ─── Icon rail variant — narrow with popover-style sections ──────────────
const RailSidebar = ({ activeRail, onRail, onAI }) => {
  const items = [
    { id: 'song', icon: <I.Music size={16}/>, label: 'Song' },
    { id: 'layout', icon: <I.House size={16}/>, label: 'Layout' },
    { id: 'fx', icon: <I.Sparkles size={16}/>, label: 'Effects' },
    { id: 'ai', icon: <I.Wand size={16}/>, label: 'AI' },
  ];
  return (
    <div style={{ width: 56, borderRight: '1px solid var(--line)', background: 'var(--surface)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '10px 0', gap: 4 }}>
      {items.map(it => (
        <button key={it.id} onClick={() => onRail(it.id === activeRail ? null : it.id)}
          title={it.label} className="btn ghost"
          style={{ width: 40, height: 40, padding: 0, borderRadius: 8,
            background: activeRail === it.id ? 'var(--accent-50)' : 'transparent',
            color: activeRail === it.id ? 'var(--accent-ink)' : 'var(--ink-2)' }}>
          {it.icon}
        </button>
      ))}
      <div style={{ flex: 1 }}/>
      <button className="btn ghost" style={{ width: 40, height: 40, padding: 0 }}><I.Settings size={16}/></button>
    </div>
  );
};

window.TopBar = TopBar;
window.LeftSidebar = LeftSidebar;
window.RailSidebar = RailSidebar;
window.SidebarSection = SidebarSection;
