// Editor — composes shell, tabs, AI panel, export modal.

const Editor = ({ project, onBack, variant = 'default', tweaks }) => {
  const [tab, setTab] = React.useState('timeline');
  const [showAI, setShowAI] = React.useState(false);
  const [showExport, setShowExport] = React.useState(false);
  const [time, setTime] = React.useState(2.4);
  const [playing, setPlaying] = React.useState(false);
  const [activeRail, setActiveRail] = React.useState(null);
  const [layoutMode, setLayoutMode] = React.useState('freeform');

  const tabs = [
    { id: 'timeline', label: 'Audio Timeline', icon: <I.Wave size={14}/> },
    { id: 'layout',   label: 'Layout',         icon: <I.House size={14}/> },
    { id: 'preview',  label: 'Preview',        icon: <I.Eye size={14}/> },
  ];

  const density = variant === 'dense' ? 'compact' : 'comfy';

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TopBar projectName={project?.name || 'Wizards in Winter'} onBack={onBack}
        onExport={() => setShowExport(true)} onAI={() => setShowAI(true)} dirty/>

      <div style={{ flex: 1, display: 'flex', minHeight: 0, position: 'relative' }}>
        {variant === 'rail' ? (
          <>
            <RailSidebar activeRail={activeRail} onRail={setActiveRail} onAI={() => setShowAI(true)}/>
            {activeRail && (
              <div style={{ width: 240, borderRight: '1px solid var(--line)', background: 'var(--surface)',
                overflowY: 'auto' }}>
                {activeRail === 'song' && (
                  <SidebarSection title="Song"><div style={{ background: 'var(--panel)', border: '1px solid var(--line)', borderRadius: 8, padding: 10, display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 6, background: 'linear-gradient(135deg, oklch(60% 0.18 250), oklch(72% 0.13 200))',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><I.Music size={16}/></div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: 12.5, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>Wizards in Winter</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>140 BPM · D minor</div>
                    </div></div>
                    <button className="btn sm" style={{ width: '100%', marginTop: 8, justifyContent: 'center' }}><I.Upload size={13}/> Replace song</button>
                  </SidebarSection>
                )}
                {activeRail === 'layout' && (
                  <SidebarSection title="Fixtures">
                    {FIXTURES.map(f => (
                      <div key={f.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 6px', fontSize: 12.5 }}>
                        <div style={{ width: 18, height: 18, borderRadius: 4, background: 'var(--accent-50)', color: 'var(--accent-ink)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{f.icon}</div>
                        <span style={{ flex: 1 }}>{f.name}</span>
                        <span style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>×{f.count}</span>
                      </div>
                    ))}
                  </SidebarSection>
                )}
                {activeRail === 'fx' && (
                  <SidebarSection title="Effects">
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
                      {EFFECTS.map(fx => (
                        <div key={fx.id} draggable style={{ padding: '6px 8px', borderRadius: 5,
                          border: '1px solid var(--line)', background: 'var(--surface)',
                          fontSize: 11.5, fontWeight: 500, cursor: 'grab', display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ width: 8, height: 8, borderRadius: 2, background: fx.color }}/>
                          <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{fx.name}</span>
                        </div>
                      ))}
                    </div>
                  </SidebarSection>
                )}
                {activeRail === 'ai' && (
                  <SidebarSection title="AI Actions">
                    <button className="btn primary sm" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 6 }} onClick={() => setShowAI(true)}>
                      <I.Sparkles size={13}/> Generate sequence
                    </button>
                    <button className="btn sm" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 6 }} onClick={() => setShowAI(true)}>
                      <I.Wave size={13}/> Analyze audio
                    </button>
                    <button className="btn sm" style={{ width: '100%', justifyContent: 'flex-start' }} onClick={() => setShowAI(true)}>
                      <I.Eyedrop size={13}/> Generate palette
                    </button>
                  </SidebarSection>
                )}
              </div>
            )}
          </>
        ) : (
          <LeftSidebar onAI={() => setShowAI(true)} activeTab={tab} compact={variant === 'dense'}/>
        )}

        {/* main content area */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          {/* tabs */}
          <div style={{ height: 42, display: 'flex', alignItems: 'flex-end', padding: '0 14px',
            background: 'var(--bg)', borderBottom: '1px solid var(--line)', gap: 2, flexShrink: 0 }}>
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                style={{ display: 'flex', alignItems: 'center', gap: 6, height: 32, padding: '0 14px',
                  border: '1px solid', borderColor: tab === t.id ? 'var(--line)' : 'transparent',
                  borderBottom: tab === t.id ? '1px solid var(--bg)' : 'none', position: 'relative', bottom: -1,
                  background: tab === t.id ? 'var(--bg)' : 'transparent',
                  color: tab === t.id ? 'var(--ink)' : 'var(--ink-3)',
                  fontSize: 13, fontWeight: tab === t.id ? 600 : 500, cursor: 'pointer',
                  borderTopLeftRadius: 6, borderTopRightRadius: 6 }}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {tab === 'timeline' && <Timeline density={tweaks.timelineDensity || density}
            blockStyle={tweaks.blockStyle || 'solid'}
            annotations={tweaks.annotations}
            time={time} setTime={setTime} playing={playing} setPlaying={setPlaying}/>}
          {tab === 'layout'   && <LayoutTab annotations={tweaks.annotations} mode={layoutMode} setMode={setLayoutMode}/>}
          {tab === 'preview'  && <PreviewTab time={time} setTime={setTime}
            playing={playing} setPlaying={setPlaying} annotations={tweaks.annotations}/>}
        </div>

        {showAI && <AIPanel onClose={() => setShowAI(false)} scoped/>}
      </div>

      {showExport && <ExportModal onClose={() => setShowExport(false)} scoped/>}
    </div>
  );
};

window.Editor = Editor;
