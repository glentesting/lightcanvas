// Preview tab — house image with animated effect overlay derived from
// timeline state. Plays the show on the illustrated house.

const PreviewTab = ({ time, playing, setTime, setPlaying, annotations }) => {
  // Derive what's "active" at the current time from SEQ
  const active = SEQ.filter(s => time >= s.t && time < s.t + s.d);
  const intensityFor = (track) => {
    const e = active.find(a => a.track === track);
    if (!e) return null;
    const fxC = EFFECTS.find(x => x.id === e.fx);
    const localT = (time - e.t) / e.d;
    let intensity = 1;
    if (e.fx === 'fade') intensity = 0.4 + 0.4 * Math.sin(time * 1.6);
    else if (e.fx === 'pulse') intensity = 0.4 + 0.5 * Math.abs(Math.sin(time * 4.6));
    else if (e.fx === 'strobe') intensity = (Math.floor(time * 8) % 2) ? 0.95 : 0.05;
    else if (e.fx === 'sparkle' || e.fx === 'twinkle') intensity = 0.55 + 0.45 * Math.sin(time * 3 + e.t);
    else intensity = 0.85;
    return { color: fxC?.color || 'oklch(70% 0.13 var(--accent-h))', intensity, outline: track === 'windows', pattern: e.fx };
  };

  // play loop — same as Timeline's
  React.useEffect(() => {
    if (!playing) return;
    let raf, last = performance.now();
    const tick = (now) => {
      const dt = (now - last) / 1000;
      last = now;
      setTime(t => {
        const nt = t + dt;
        if (nt >= 30) { setPlaying(false); return 0; }
        return nt;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, setTime, setPlaying]);

  const lights = {
    roofline: intensityFor('roofline'),
    windows: intensityFor('windows'),
    bushes: intensityFor('bushes'),
    megaTree: intensityFor('megaTree'),
    miniTrees: intensityFor('miniTrees'),
    arches: intensityFor('arches'),
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0, background: 'var(--bg)' }}>
      {/* preview canvas */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', background: 'linear-gradient(135deg, #f0eee9, #e6e3dc)' }}>
        <div style={{ position: 'relative', borderRadius: 10, overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(20,22,28,.18)' }}>
          <House width={780} height={460} lights={lights} time={time} snow/>
        </div>

        {/* now playing chip */}
        <div style={{ position: 'absolute', top: 18, left: 18, display: 'flex', gap: 8 }}>
          <div className="chip" style={{ background: 'var(--surface)', borderColor: 'var(--line)' }}>
            <span className="dot" style={{ background: playing ? 'var(--xmas-grn)' : 'var(--ink-4)',
              animation: playing ? 'pulse-ring 1.6s infinite' : 'none' }}/>
            {playing ? 'Playing' : 'Paused'}
          </div>
          <div className="chip muted">
            <span className="dot"/>{active.length} effect{active.length===1?'':'s'} active
          </div>
        </div>

        {/* fullscreen toggle */}
        <button className="btn sm" style={{ position: 'absolute', top: 18, right: 18 }}>
          <I.Eye size={13}/> Fullscreen
        </button>

        {annotations && (
          <span className="pin" style={{ top: 60, right: 80 }}>4
            <span className="tip">Live preview. Lights animate to match the timeline at the current playhead.</span>
          </span>
        )}
      </div>

      {/* transport with mini scrubber */}
      <div style={{ height: 80, borderTop: '1px solid var(--line)', background: 'var(--surface)',
        padding: '12px 18px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="btn sm" onClick={() => setTime(0)}><I.Skip size={13} style={{ transform: 'scaleX(-1)' }}/></button>
          <button className="btn primary" onClick={() => setPlaying(p => !p)} style={{ width: 36, height: 32, padding: 0, justifyContent: 'center' }}>
            {playing ? <I.Pause size={14}/> : <I.Play size={14}/>}
          </button>
          <button className="btn sm"><I.Stop size={13}/></button>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--ink-2)',
            padding: '4px 10px', background: 'var(--panel)', borderRadius: 5,
            fontVariantNumeric: 'tabular-nums', minWidth: 130 }}>
            {String(Math.floor(time/60)).padStart(2,'0')}:{String(Math.floor(time%60)).padStart(2,'0')}.{String(Math.floor((time%1)*100)).padStart(2,'0')} <span style={{ color: 'var(--ink-4)' }}>/ 03:04</span>
          </div>
          <div style={{ flex: 1 }}/>
          <span className="chip muted"><span className="dot"/>1×</span>
          <button className="btn sm ghost" title="Loop"><I.Wave size={14}/></button>
        </div>
        {/* scrubber strip with effect blocks shown small */}
        <div style={{ position: 'relative', height: 18, background: 'var(--panel)', borderRadius: 4, cursor: 'pointer' }}
          onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            setTime(((e.clientX - r.left) / r.width) * 30);
          }}>
          {SEQ.map((s, i) => (
            <div key={i} style={{ position: 'absolute', left: `${s.t/30*100}%`, top: 4, height: 10,
              width: `${s.d/30*100}%`, background: EFFECTS.find(x=>x.id===s.fx).color, opacity: 0.55, borderRadius: 2 }}/>
          ))}
          <div style={{ position: 'absolute', left: `${time/30*100}%`, top: -2, bottom: -2, width: 2, background: 'var(--xmas-red)' }}/>
        </div>
      </div>
    </div>
  );
};

window.PreviewTab = PreviewTab;
