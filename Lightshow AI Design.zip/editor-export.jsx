// Export modal — light-mode (no dark overlay).

const ExportModal = ({ onClose, scoped = false }) => {
  const [format, setFormat] = React.useState('fseq');
  const [phase, setPhase] = React.useState('config'); // config | exporting | done
  const [progress, setProgress] = React.useState(0);
  const [stage, setStage] = React.useState('');

  const formats = [
    { id: 'fseq', name: 'xLights', sub: '.fseq sequence file', desc: 'Standard FPP/xLights format. Most controllers.', tag: 'Recommended' },
    { id: 'lor',  name: 'Light-O-Rama', sub: '.lms intensity file', desc: 'For LOR controllers and ShowTime software.' },
    { id: 'dmx',  name: 'E1.31 / sACN', sub: 'streaming DMX', desc: 'Direct streaming to DMX universes. For pixel controllers.' },
  ];

  const stages = ['Compiling sequence…', 'Mapping channels…', 'Encoding 30 fps frames…', 'Writing file…'];

  const startExport = () => {
    setPhase('exporting');
    setProgress(0);
    let p = 0, s = 0;
    setStage(stages[0]);
    const tick = () => {
      p = Math.min(100, p + 8 + Math.random() * 6);
      setProgress(Math.round(p));
      const ns = Math.min(stages.length - 1, Math.floor(p / 26));
      if (ns !== s) { s = ns; setStage(stages[s]); }
      if (p < 100) setTimeout(tick, 180);
      else setTimeout(() => setPhase('done'), 300);
    };
    setTimeout(tick, 250);
  };

  return (
    <div className="modal-backdrop" onClick={onClose}
      style={scoped ? { position: 'absolute', inset: 0 } : null}>
      <div className="modal fade-in" style={{ width: 540 }} onClick={e => e.stopPropagation()}>
        <div style={{ padding: '20px 24px 14px', borderBottom: '1px solid var(--line)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 7, background: 'var(--accent-50)',
              color: 'var(--accent-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.Export size={14}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 16 }}>Export show</div>
              <div style={{ fontSize: 12.5, color: 'var(--ink-3)' }}>Wizards in Winter · 3:04 · 988 pixels</div>
            </div>
            <button className="btn ghost sm" onClick={onClose} style={{ padding: 0, width: 28, height: 28 }}>
              <I.X size={14}/>
            </button>
          </div>
        </div>

        {phase === 'config' && (
          <div style={{ padding: 20 }}>
            <div style={{ fontSize: 12, fontWeight: 600, letterSpacing: 0.04, textTransform: 'uppercase',
              color: 'var(--ink-3)', marginBottom: 10 }}>Choose format</div>
            <div style={{ display: 'grid', gap: 8, marginBottom: 18 }}>
              {formats.map(f => (
                <button key={f.id} onClick={() => setFormat(f.id)} className="btn"
                  style={{ height: 'auto', padding: 14, justifyContent: 'flex-start', textAlign: 'left',
                    borderColor: format === f.id ? 'var(--accent)' : 'var(--line)',
                    boxShadow: format === f.id ? '0 0 0 3px var(--accent-100)' : 'none' }}>
                  <div style={{ width: 38, height: 38, borderRadius: 7, background: 'var(--panel)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: 12, flexShrink: 0,
                    color: 'var(--ink-2)' }}>
                    <I.Download size={16}/>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{f.name}</span>
                      <span style={{ fontSize: 11.5, color: 'var(--ink-4)' }}>{f.sub}</span>
                      {f.tag && <span className="chip" style={{ marginLeft: 4 }}><span className="dot"/>{f.tag}</span>}
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 2, fontWeight: 400 }}>{f.desc}</div>
                  </div>
                  <div style={{ width: 18, height: 18, borderRadius: '50%', border: '2px solid var(--line)',
                    background: format === f.id ? 'var(--accent)' : 'transparent',
                    borderColor: format === f.id ? 'var(--accent)' : 'var(--line-2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {format === f.id && <I.Check size={10} stroke="#fff" sw={3}/>}
                  </div>
                </button>
              ))}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
              <div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 4 }}>Frame rate</div>
                <select className="btn" style={{ width: '100%' }}>
                  <option>30 fps (recommended)</option><option>20 fps</option><option>50 fps</option>
                </select>
              </div>
              <div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 4 }}>Audio</div>
                <select className="btn" style={{ width: '100%' }}>
                  <option>Bundle WAV with sequence</option><option>Sequence only</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {phase === 'exporting' && (
          <div style={{ padding: 28, textAlign: 'center' }}>
            <div style={{ width: 60, height: 60, borderRadius: '50%', background: 'var(--accent-50)',
              margin: '0 auto 18px', display: 'flex', alignItems: 'center', justifyContent: 'center',
              animation: 'pulse-ring 1.6s infinite' }}>
              <I.Loader size={26} className="spin" style={{ color: 'var(--accent-700)' }}/>
            </div>
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 4 }}>Exporting your show…</div>
            <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 18 }}>{stage}</div>
            <div style={{ height: 6, background: 'var(--panel)', borderRadius: 3, overflow: 'hidden', maxWidth: 360, margin: '0 auto' }}>
              <div style={{ width: `${progress}%`, height: '100%', background: 'var(--accent)', transition: 'width .25s' }}/>
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-4)', marginTop: 8, fontVariantNumeric: 'tabular-nums' }}>{progress}%</div>
          </div>
        )}

        {phase === 'done' && (
          <div style={{ padding: 28, textAlign: 'center' }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'oklch(94% 0.08 145)',
              color: 'oklch(48% 0.16 145)', margin: '0 auto 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <I.Check size={26} sw={2.5}/>
            </div>
            <div style={{ fontWeight: 600, fontSize: 16, marginBottom: 4 }}>Ready to download</div>
            <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 18 }}>
              wizards-in-winter.{format === 'fseq' ? 'fseq' : format === 'lor' ? 'lms' : 'zip'} · 4.2 MB
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
              <button className="btn">Show in folder</button>
              <button className="btn primary"><I.Download size={14}/> Download file</button>
            </div>
          </div>
        )}

        {phase === 'config' && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 20px',
            borderTop: '1px solid var(--line)', background: 'var(--panel)' }}>
            <button className="btn" onClick={onClose}>Cancel</button>
            <button className="btn primary" onClick={startExport}><I.Download size={14}/> Export</button>
          </div>
        )}
      </div>
    </div>
  );
};

window.ExportModal = ExportModal;
