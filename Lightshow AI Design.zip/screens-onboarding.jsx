// Welcome / Auth / Onboarding — the pre-app screens.

const Logo = ({ size = 22, withText = true }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <defs>
        <radialGradient id="lg" cx="0.5" cy="0.4" r="0.6">
          <stop offset="0" stopColor="oklch(85% 0.15 var(--accent-h))"/>
          <stop offset="1" stopColor="oklch(55% 0.18 var(--accent-h))"/>
        </radialGradient>
      </defs>
      <circle cx="12" cy="12" r="9" fill="url(#lg)"/>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="1.4" opacity="0.15"/>
      <circle cx="9" cy="10" r="1.6" fill="#fff" opacity="0.9"/>
    </svg>
    {withText && <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 18, letterSpacing: -0.3 }}>Lumen</span>}
  </div>
);

const WelcomeScreen = ({ onContinue, xmas }) => (
  <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', background:
    'radial-gradient(ellipse 1200px 600px at 50% -10%, var(--accent-50), transparent 60%), var(--bg)' }}>
    <div style={{ padding: '20px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Logo />
      <div style={{ display: 'flex', gap: 8 }}>
        <button className="btn ghost sm">Sign in</button>
        <button className="btn primary sm" onClick={onContinue}>Get started</button>
      </div>
    </div>

    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 24px' }}>
      <div style={{ maxWidth: 880, textAlign: 'center' }}>
        <div className="chip" style={{ marginBottom: 20 }}>
          <span className="dot" style={{background: xmas ? 'var(--xmas-red)' : undefined}}/>
          New · AI sequencing for the holidays
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 'clamp(36px, 5vw, 64px)',
          letterSpacing: -1.2, lineHeight: 1.05, margin: '0 0 18px', textWrap: 'balance' }}>
          Light shows, without the spreadsheet.
        </h1>
        <p style={{ fontSize: 18, color: 'var(--ink-3)', maxWidth: 560, margin: '0 auto 28px', textWrap: 'pretty' }}>
          Drop in a song. Sketch your house. Let Lumen sequence the lights.
          Export to xLights, Light-O-Rama, or DMX when you&rsquo;re happy.
        </p>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginBottom: 48 }}>
          <button className="btn primary lg" onClick={onContinue}>
            <I.Sparkles size={16}/> Start designing
          </button>
          <button className="btn lg">Watch a 60-sec demo</button>
        </div>

        {/* feature row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, textAlign: 'left',
          background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 14, padding: 20, boxShadow: 'var(--shadow)' }}>
          {[
            {icon: <I.Music size={18}/>, t: 'Beat-aware sequencing', d: 'Lumen listens to your song and times effects to the kick, snare, and melody.'},
            {icon: <I.House size={18}/>, t: 'Sketch your house', d: 'Upload a photo or use the illustrated layout. Snap-to-grid or freeform.'},
            {icon: <I.Export size={18}/>, t: 'Exports you trust', d: 'xLights .fseq, LOR intensity, or E1.31/DMX. No format hostage.'},
          ].map((f, i) => (
            <div key={i} style={{ padding: 4 }}>
              <div style={{ display: 'inline-flex', padding: 8, borderRadius: 8, background: 'var(--accent-50)',
                color: 'var(--accent-ink)', marginBottom: 10 }}>{f.icon}</div>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{f.t}</div>
              <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>{f.d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>

    <div style={{ padding: '16px 32px', color: 'var(--ink-4)', fontSize: 12, textAlign: 'center' }}>
      Works alongside xLights, Light-O-Rama, and any E1.31-compatible controller.
    </div>
  </div>
);

const AuthScreen = ({ mode = 'signup', onContinue, onSwitch }) => {
  const isSignup = mode === 'signup';
  return (
    <div style={{ minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', padding: 24 }}>
      <div style={{ width: 400, background: 'var(--surface)', border: '1px solid var(--line)',
        borderRadius: 14, boxShadow: 'var(--shadow-lg)', padding: 28 }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 18 }}><Logo /></div>
        <h2 style={{ textAlign: 'center', fontSize: 22, fontWeight: 600, margin: '0 0 6px',
          fontFamily: 'var(--font-display)', letterSpacing: -0.4 }}>
          {isSignup ? 'Create your account' : 'Welcome back'}
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--ink-3)', fontSize: 13.5, margin: '0 0 22px' }}>
          {isSignup ? 'Start your first show in under a minute.' : 'Sign in to continue.'}
        </p>

        <button className="btn" style={{ width: '100%', justifyContent: 'center', marginBottom: 8, height: 38 }}>
          <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22 12.2c0-.7-.1-1.4-.2-2H12v3.8h5.6a4.8 4.8 0 0 1-2 3.2v2.7h3.3c2-1.8 3.1-4.5 3.1-7.7Z"/><path fill="#34A853" d="M12 22c2.7 0 5-.9 6.7-2.4l-3.3-2.6a6 6 0 0 1-9-3.2H3v2.7A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.8a6 6 0 0 1 0-3.6V7.5H3a10 10 0 0 0 0 9l3.4-2.7Z"/><path fill="#EA4335" d="M12 6c1.5 0 2.9.5 3.9 1.5l2.9-2.9A10 10 0 0 0 3 7.5l3.4 2.7A6 6 0 0 1 12 6Z"/></svg>
          Continue with Google
        </button>
        <button className="btn" style={{ width: '100%', justifyContent: 'center', marginBottom: 16, height: 38 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 12.5a4.5 4.5 0 0 1 2.1-3.7 4.6 4.6 0 0 0-3.6-1.9c-1.5-.2-3 .9-3.7.9-.8 0-2-.9-3.3-.9-1.7 0-3.3 1-4.2 2.5-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.3 2.5 1.3-.1 1.8-.8 3.4-.8 1.6 0 2 .8 3.4.8 1.4 0 2.3-1.2 3.2-2.5a11 11 0 0 0 1.4-3 4.4 4.4 0 0 1-2.3-4.1ZM14.5 5.3a4.5 4.5 0 0 0 1-3.3 4.5 4.5 0 0 0-3 1.5 4.2 4.2 0 0 0-1 3.2 3.7 3.7 0 0 0 3-1.4Z"/></svg>
          Continue with Apple
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '4px 0 16px', color: 'var(--ink-4)', fontSize: 12 }}>
          <div style={{flex:1, height:1, background:'var(--line)'}}/>or<div style={{flex:1, height:1, background:'var(--line)'}}/>
        </div>

        <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: 'var(--ink-3)', marginBottom: 6 }}>Email</label>
        <div style={{ position:'relative', marginBottom: 12 }}>
          <I.Mail size={14} style={{ position:'absolute', left: 11, top: '50%', transform:'translateY(-50%)', color: 'var(--ink-4)' }}/>
          <input type="email" defaultValue="alex@example.com" style={{ width:'100%', height: 38, border:'1px solid var(--line)',
            borderRadius: 8, padding: '0 12px 0 32px', background: 'var(--surface)', fontSize: 13.5, outline: 'none' }}
            onFocus={e => e.target.style.borderColor = 'var(--accent)'}
            onBlur={e => e.target.style.borderColor = 'var(--line)'}/>
        </div>
        <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: 'var(--ink-3)', marginBottom: 6 }}>Password</label>
        <div style={{ position:'relative', marginBottom: 18 }}>
          <I.Lock size={14} style={{ position:'absolute', left: 11, top: '50%', transform:'translateY(-50%)', color: 'var(--ink-4)' }}/>
          <input type="password" defaultValue="••••••••••" style={{ width:'100%', height: 38, border:'1px solid var(--line)',
            borderRadius: 8, padding: '0 12px 0 32px', background: 'var(--surface)', fontSize: 13.5, outline: 'none' }}/>
        </div>

        <button className="btn primary lg" style={{ width: '100%', justifyContent: 'center' }} onClick={onContinue}>
          {isSignup ? 'Create account' : 'Sign in'} <I.ChevR size={14}/>
        </button>

        <div style={{ textAlign: 'center', marginTop: 16, fontSize: 13, color: 'var(--ink-3)' }}>
          {isSignup ? 'Already have an account?' : 'New to Lumen?'}{' '}
          <a onClick={onSwitch} style={{ color: 'var(--accent-700)', cursor: 'pointer', fontWeight: 500 }}>
            {isSignup ? 'Sign in' : 'Create one'}
          </a>
        </div>
      </div>
    </div>
  );
};

const OnboardingScreen = ({ onDone }) => {
  const [step, setStep] = React.useState(0);
  const steps = [
    {
      title: 'Tell us about your setup',
      sub: 'We&rsquo;ll tailor defaults to match your controller and scale.',
      body: (
        <div style={{ display: 'grid', gap: 12 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--ink-3)', marginBottom: 6 }}>Controller</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {['xLights / Falcon','Light-O-Rama','E1.31 / sACN'].map((c, i) => (
                <button key={c} className="btn" style={{ flexDirection: 'column', height: 64, padding: 8,
                  borderColor: i===0 ? 'var(--accent)' : 'var(--line)', background: i===0 ? 'var(--accent-50)' : 'var(--surface)' }}>
                  <I.Settings size={16}/>
                  <span style={{ fontSize: 12 }}>{c}</span>
                </button>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--ink-3)', marginBottom: 6 }}>Scale</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {[{n:'Casual',d:'<5k pixels'},{n:'Enthusiast',d:'5–20k pixels'},{n:'Mega display',d:'20k+'}].map((s, i) => (
                <button key={s.n} className="btn" style={{ flexDirection: 'column', alignItems: 'flex-start', height: 56, padding: '8px 12px',
                  borderColor: i===1 ? 'var(--accent)' : 'var(--line)', background: i===1 ? 'var(--accent-50)' : 'var(--surface)' }}>
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{s.n}</span>
                  <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>{s.d}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'How does Lumen work?',
      sub: 'Three simple steps for every show.',
      body: (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {[
            {n:'1', t:'Upload', d:'Drop in a song. We detect tempo and beats.', icon: <I.Music size={18}/>},
            {n:'2', t:'Layout', d:'Sketch your house — roofline, windows, trees.', icon: <I.House size={18}/>},
            {n:'3', t:'Generate', d:'Lumen sequences effects to match the music.', icon: <I.Sparkles size={18}/>},
          ].map(s => (
            <div key={s.n} style={{ padding: 14, border: '1px solid var(--line)', borderRadius: 10, background: 'var(--panel)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <div style={{ width: 22, height: 22, borderRadius: 6, background: 'var(--accent)', color: '#fff',
                  fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{s.n}</div>
                <div style={{ color: 'var(--accent-ink)' }}>{s.icon}</div>
              </div>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{s.t}</div>
              <div style={{ fontSize: 12.5, color: 'var(--ink-3)' }}>{s.d}</div>
            </div>
          ))}
        </div>
      ),
    },
    {
      title: 'Try the sample project',
      sub: 'We&rsquo;ve loaded "Wizards in Winter" so you can play right away.',
      body: (
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', padding: 16, border: '1px solid var(--line)', borderRadius: 10, background: 'var(--panel)' }}>
          <div style={{ width: 88, height: 88, borderRadius: 8, background:
            'linear-gradient(135deg, oklch(60% 0.18 250), oklch(72% 0.13 200))',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', flexShrink: 0 }}>
            <I.Music size={28}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, marginBottom: 2 }}>Wizards in Winter</div>
            <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>Trans-Siberian Orchestra · 3:04</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <span className="chip muted"><span className="dot"/>BPM 140</span>
              <span className="chip muted"><span className="dot"/>Key D minor</span>
              <span className="chip muted"><span className="dot"/>High energy</span>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const s = steps[step];
  return (
    <div style={{ minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', padding: 24 }}>
      <div style={{ width: 620, background: 'var(--surface)', border: '1px solid var(--line)',
        borderRadius: 14, boxShadow: 'var(--shadow-lg)', overflow: 'hidden' }}>
        {/* progress */}
        <div style={{ display: 'flex', gap: 4, padding: '14px 20px 0' }}>
          {steps.map((_, i) => (
            <div key={i} style={{ flex: 1, height: 4, borderRadius: 2,
              background: i <= step ? 'var(--accent)' : 'var(--line)' }}/>
          ))}
        </div>
        <div style={{ padding: '20px 28px 8px', fontSize: 12, color: 'var(--ink-3)', fontWeight: 500 }}>
          Step {step+1} of {steps.length}
        </div>
        <div style={{ padding: '0 28px 20px' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 24, letterSpacing: -0.4, margin: '0 0 6px' }} dangerouslySetInnerHTML={{__html: s.title}}/>
          <p style={{ color: 'var(--ink-3)', margin: '0 0 18px', fontSize: 14 }} dangerouslySetInnerHTML={{__html: s.sub}}/>
          {s.body}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 20px',
          background: 'var(--panel)', borderTop: '1px solid var(--line)' }}>
          <button className="btn ghost" onClick={() => step > 0 ? setStep(step-1) : null}>Back</button>
          <button className="btn primary" onClick={() => step < steps.length-1 ? setStep(step+1) : onDone()}>
            {step < steps.length-1 ? 'Continue' : 'Open the editor'} <I.ChevR size={14}/>
          </button>
        </div>
      </div>
    </div>
  );
};

window.WelcomeScreen = WelcomeScreen;
window.AuthScreen = AuthScreen;
window.OnboardingScreen = OnboardingScreen;
window.Logo = Logo;
