// Simple inline icons — stroke style, 1.6px, square caps. No emoji.
const Icon = ({ d, size = 16, fill = false, stroke = 'currentColor', sw = 1.6, children, style, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill ? stroke : 'none'} stroke={fill ? 'none' : stroke}
    strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style} {...rest}>
    {d ? <path d={d} /> : children}
  </svg>
);

const I = {
  Plus:    (p) => <Icon {...p}><path d="M12 5v14M5 12h14"/></Icon>,
  Search:  (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>,
  Folder:  (p) => <Icon {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/></Icon>,
  Music:   (p) => <Icon {...p}><path d="M9 18V6l12-2v12"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></Icon>,
  Wand:    (p) => <Icon {...p}><path d="m4 20 12-12"/><path d="m14 6 4 4"/><path d="M3 4v3M3 5.5h3M19 17v3M19 18.5h3M9 3v2M9 4h2"/></Icon>,
  Sparkles:(p) => <Icon {...p}><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="2.5"/></Icon>,
  Layers:  (p) => <Icon {...p}><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/></Icon>,
  Layout:  (p) => <Icon {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M3 12h6"/></Icon>,
  Play:    (p) => <Icon {...p}><path d="M7 5v14l11-7-11-7Z"/></Icon>,
  Pause:   (p) => <Icon {...p}><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></Icon>,
  Stop:    (p) => <Icon {...p}><rect x="5" y="5" width="14" height="14" rx="1.5"/></Icon>,
  Skip:    (p) => <Icon {...p}><path d="M5 5v14l9-7-9-7Z"/><path d="M19 5v14"/></Icon>,
  Save:    (p) => <Icon {...p}><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h9"/></Icon>,
  Export:  (p) => <Icon {...p}><path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 17v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2"/></Icon>,
  Download:(p) => <Icon {...p}><path d="M12 15V3M7 10l5 5 5-5"/><path d="M5 17v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2"/></Icon>,
  Upload:  (p) => <Icon {...p}><path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 17v2a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2"/></Icon>,
  House:   (p) => <Icon {...p}><path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/></Icon>,
  Bulb:    (p) => <Icon {...p}><path d="M9 18h6M10 21h4M9 14a5 5 0 1 1 6 0c-.7.5-1 1.2-1 2v1h-4v-1c0-.8-.3-1.5-1-2Z"/></Icon>,
  Settings:(p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></Icon>,
  X:       (p) => <Icon {...p}><path d="M18 6 6 18M6 6l12 12"/></Icon>,
  Check:   (p) => <Icon {...p}><path d="m5 12 5 5L20 7"/></Icon>,
  ChevR:   (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>,
  ChevL:   (p) => <Icon {...p}><path d="m15 6-6 6 6 6"/></Icon>,
  ChevD:   (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>,
  Mail:    (p) => <Icon {...p}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></Icon>,
  Lock:    (p) => <Icon {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Icon>,
  Eye:     (p) => <Icon {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></Icon>,
  Trash:   (p) => <Icon {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/></Icon>,
  More:    (p) => <Icon {...p}><circle cx="5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="19" cy="12" r="1.4"/></Icon>,
  Pencil:  (p) => <Icon {...p}><path d="M4 20h4l11-11-4-4L4 16v4Z"/><path d="m13 6 4 4"/></Icon>,
  Drag:    (p) => <Icon {...p}><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></Icon>,
  Pen:     (p) => <Icon {...p}><path d="M12 19l7-7-3-3-7 7v3h3Z"/><path d="m14 7 3 3"/></Icon>,
  Cursor:  (p) => <Icon {...p}><path d="M5 3l5 16 2.5-7L20 9 5 3Z"/></Icon>,
  Grid:    (p) => <Icon {...p}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></Icon>,
  Wave:    (p) => <Icon {...p}><path d="M2 12c2 0 2-6 4-6s2 12 4 12 2-12 4-12 2 12 4 12 2-6 4-6"/></Icon>,
  Zap:     (p) => <Icon {...p}><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/></Icon>,
  Tree:    (p) => <Icon {...p}><path d="M12 3 6 11h3l-4 6h5v4h4v-4h5l-4-6h3l-6-8Z"/></Icon>,
  Snow:    (p) => <Icon {...p}><path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M5.6 18.4 18.4 5.6"/></Icon>,
  Eyedrop: (p) => <Icon {...p}><path d="m13 6 5 5L8 21H3v-5L13 6Z"/><path d="m13 6 3-3 5 5-3 3"/></Icon>,
  Loader:  (p) => <Icon {...p}><path d="M12 3a9 9 0 1 0 9 9" /></Icon>,
};

window.I = I;
window.Icon = Icon;
