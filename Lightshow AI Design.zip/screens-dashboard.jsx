// Dashboard

const Dashboard = ({ onOpenProject, onNew }) => {
  const projects = [
    { id: 'p1', name: 'Wizards in Winter', song: 'Trans-Siberian Orchestra', edited: 'Edited 2 minutes ago', status: 'In progress', sequenced: 78, fixtures: 6, color: 'oklch(62% 0.18 250)', sample: true },
    { id: 'p2', name: 'Carol of the Bells — 2026', song: 'Lindsey Stirling', edited: 'Edited yesterday', status: 'Draft', sequenced: 22, fixtures: 8, color: 'oklch(70% 0.13 200)' },
    { id: 'p3', name: 'Front yard — Halloween', song: 'Thriller', edited: 'Edited Oct 28', status: 'Exported', sequenced: 100, fixtures: 5, color: 'oklch(72% 0.16 30)' },
    { id: 'p4', name: 'Hallelujah (instrumental)', song: 'Pentatonix', edited: 'Edited 2 weeks ago', status: 'Draft', sequenced: 8, fixtures: 4, color: 'oklch(68% 0.15 320)' },
  ];

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)' }}>
      {/* top bar */}
      <div style={{ borderBottom: '1px solid var(--line)', background: 'var(--surface)' }}>
        <div style={{ maxWidth: 1180, margin: '0 auto', padding: '14px 28px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Logo />
          <div style={{ flex: 1, maxWidth: 380, margin: '0 24px', position: 'relative' }}>
            <I.Search size={14} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-4)' }}/>
            <input placeholder="Search projects" style={{ width: '100%', height: 32, border: '1px solid var(--line)',
              borderRadius: 8, padding: '0 12px 0 32px', background: 'var(--panel)', fontSize: 13, outline: 'none' }}/>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button className="btn sm ghost"><I.Settings size={14}/></button>
            <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--accent-100)',
              color: 'var(--accent-ink)', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 600 }}>AC</div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1180, margin: '0 auto', padding: '36px 28px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--ink-3)', marginBottom: 6 }}>Welcome back, Alex</div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 34, letterSpacing: -0.6, margin: 0 }}>
              Your shows
            </h1>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn"><I.Upload size={14}/> Import .fseq</button>
            <button className="btn primary" onClick={onNew}><I.Plus size={14}/> New project</button>
          </div>
        </div>

        {/* tabs */}
        <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--line)', marginBottom: 20 }}>
          {['All projects', 'In progress', 'Exported', 'Archived'].map((t, i) => (
            <button key={t} className="btn ghost sm" style={{
              borderRadius: 0, borderBottom: i===0 ? '2px solid var(--accent)' : '2px solid transparent',
              color: i===0 ? 'var(--ink)' : 'var(--ink-3)', fontWeight: i===0 ? 600 : 500, paddingBottom: 8, paddingTop: 8 }}>
              {t}
              {i===0 && <span style={{ marginLeft: 6, color: 'var(--ink-4)', fontWeight: 500 }}>{projects.length}</span>}
            </button>
          ))}
        </div>

        {/* grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
          {/* New project tile */}
          <button onClick={onNew} style={{ height: 220, border: '2px dashed var(--line-2)', background: 'transparent',
            borderRadius: 12, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', gap: 10, color: 'var(--ink-3)', transition: 'all .15s' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.background = 'var(--accent-50)'; e.currentTarget.style.color = 'var(--accent-ink)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--line-2)'; e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--ink-3)'; }}>
            <div style={{ width: 44, height: 44, borderRadius: 22, background: 'var(--surface)',
              border: '1px solid currentColor', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><I.Plus size={20}/></div>
            <div style={{ fontWeight: 600 }}>New project</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Start from a song or template</div>
          </button>

          {projects.map(p => (
            <div key={p.id} onClick={() => onOpenProject(p)} style={{ background: 'var(--surface)', border: '1px solid var(--line)',
              borderRadius: 12, overflow: 'hidden', cursor: 'pointer', transition: 'transform .15s, box-shadow .15s' }}
              onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}>
              {/* preview */}
              <div style={{ height: 120, background: `linear-gradient(135deg, ${p.color}, color-mix(in oklab, ${p.color}, #fff 50%))`,
                position: 'relative', overflow: 'hidden' }}>
                {/* mini house silhouette */}
                <svg viewBox="0 0 240 120" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.18 }}>
                  <polygon points="40,80 120,30 200,80 200,120 40,120" fill="#fff"/>
                  <rect x="100" y="60" width="40" height="60" fill={p.color}/>
                </svg>
                {/* light dots */}
                {Array.from({length: 12}).map((_, i) => (
                  <circle key={i} style={{ position: 'absolute' }}/>
                ))}
                <svg viewBox="0 0 240 120" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  {Array.from({length: 14}).map((_, i) => {
                    const t = i/13;
                    const x = 40 + t*160;
                    const y = 80 - Math.abs(t-0.5)*100;
                    return <circle key={i} cx={x} cy={y} r="2.4" fill="#fff" opacity={0.5 + Math.random()*0.5}/>;
                  })}
                </svg>
                {p.sample && <div style={{ position: 'absolute', top: 10, left: 10 }}>
                  <span className="chip" style={{ background: 'rgba(255,255,255,.85)', color: 'var(--ink)' }}>
                    <span className="dot" style={{ background: p.color }}/>Sample
                  </span>
                </div>}
                <div style={{ position: 'absolute', top: 10, right: 10 }}>
                  <button className="btn ghost sm" onClick={(e) => e.stopPropagation()}
                    style={{ background: 'rgba(255,255,255,.85)' }}><I.More size={14}/></button>
                </div>
              </div>
              <div style={{ padding: 14 }}>
                <div style={{ fontWeight: 600, marginBottom: 4, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
                <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginBottom: 10 }}>{p.song} · {p.edited}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className={p.status === 'Exported' ? 'chip' : 'chip muted'}>
                    <span className="dot" style={{ background: p.status === 'Exported' ? 'var(--xmas-grn)' : undefined }}/>
                    {p.status}
                  </span>
                  <div style={{ flex: 1, height: 4, background: 'var(--panel)', borderRadius: 2 }}>
                    <div style={{ width: `${p.sequenced}%`, height: '100%', background: 'var(--accent)', borderRadius: 2 }}/>
                  </div>
                  <span style={{ fontSize: 11, color: 'var(--ink-4)', fontVariantNumeric: 'tabular-nums' }}>{p.sequenced}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

window.Dashboard = Dashboard;
