// Audio Timeline tab — waveform, beat markers, draggable effect blocks.

const Timeline = ({ density = 'comfy', blockStyle = 'solid', annotations, time, setTime, playing, setPlaying }) => {
  // density: 'compact' | 'comfy' | 'cozy'
  const rowH = density === 'compact' ? 30 : density === 'cozy' ? 56 : 42;
  const headerH = density === 'compact' ? 60 : 80;
  const labelW = density === 'compact' ? 140 : 180;
  const pxPerSec = density === 'compact' ? 36 : density === 'cozy' ? 70 : 52;

  const total = 30; // showing 30s window
  const width = total * pxPerSec;

  const fxColor = (id) => EFFECTS.find(e => e.id === id)?.color || 'var(--ink-3)';
  const fxName  = (id) => EFFECTS.find(e => e.id === id)?.name || id;

  const blockStyleFor = (color) => {
    if (blockStyle === 'gradient') {
      return { background: `linear-gradient(180deg, color-mix(in oklab, ${color}, white 25%), ${color})`, color: '#fff' };
    }
    if (blockStyle === 'outlined') {
      return { background: `color-mix(in oklab, ${color}, white 80%)`, color: 'var(--ink)',
        border: `1.5px solid ${color}`, boxShadow: 'none' };
    }
    return { background: color, color: '#fff' };
  };

  const playRef = React.useRef(null);
  React.useEffect(() => {
    if (!playing) return;
    let raf, last = performance.now();
    const tick = (now) => {
      const dt = (now - last) / 1000;
      last = now;
      setTime(t => {
        const nt = t + dt;
        if (nt >= total) { setPlaying(false); return 0; }
        return nt;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, setTime, setPlaying]);

  const scrubRef = React.useRef(null);
  const onScrub = (e) => {
    const r = scrubRef.current.getBoundingClientRect();
    const x = e.clientX - r.left - labelW;
    const t = Math.max(0, Math.min(total, x / pxPerSec));
    setTime(t);
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--bg)', minHeight: 0 }}>
      {/* transport */}
      <div style={{ height: 48, borderBottom: '1px solid var(--line)', background: 'var(--surface)',
        display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10, flexShrink: 0 }}>
        <button className="btn sm" onClick={() => setTime(0)} title="Restart"><I.Skip size={13} style={{ transform: 'scaleX(-1)' }}/></button>
        <button className="btn primary" onClick={() => setPlaying(p => !p)} style={{ width: 36, height: 32, padding: 0, justifyContent: 'center' }}>
          {playing ? <I.Pause size={14}/> : <I.Play size={14}/>}
        </button>
        <button className="btn sm" onClick={() => setTime(0)} title="Stop"><I.Stop size={13}/></button>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--ink-2)',
          padding: '4px 10px', background: 'var(--panel)', borderRadius: 5, fontVariantNumeric: 'tabular-nums' }}>
          {String(Math.floor(time/60)).padStart(2,'0')}:{String(Math.floor(time%60)).padStart(2,'0')}.{String(Math.floor((time%1)*100)).padStart(2,'0')}
          <span style={{ color: 'var(--ink-4)' }}> / 03:04</span>
        </div>
        <div style={{ flex: 1 }}/>
        <span className="chip muted"><span className="dot"/>140 BPM detected</span>
        <span className="chip muted"><span className="dot"/>421 beats</span>
        <div style={{ width: 1, height: 22, background: 'var(--line)' }}/>
        <button className="btn sm ghost" title="Zoom out">−</button>
        <input type="range" min={20} max={100} defaultValue={pxPerSec} style={{ width: 90 }}/>
        <button className="btn sm ghost" title="Zoom in">+</button>
      </div>

      {/* timeline scroll area */}
      <div ref={scrubRef} style={{ flex: 1, overflow: 'auto', position: 'relative' }} onClick={onScrub}>
        <div style={{ minWidth: labelW + width + 20, position: 'relative' }}>
          {/* ruler + waveform header */}
          <div style={{ position: 'sticky', top: 0, background: 'var(--surface)',
            borderBottom: '1px solid var(--line)', zIndex: 5, display: 'flex' }}>
            {/* corner */}
            <div style={{ width: labelW, height: headerH, borderRight: '1px solid var(--line)',
              display: 'flex', alignItems: 'center', padding: '0 12px', fontSize: 11, color: 'var(--ink-3)',
              fontWeight: 600, letterSpacing: 0.04, textTransform: 'uppercase' }}>
              Tracks
            </div>
            <div style={{ position: 'relative', height: headerH, width }}>
              {/* time ruler */}
              {Array.from({length: total + 1}).map((_, s) => (
                <div key={s} style={{ position: 'absolute', left: s * pxPerSec, top: 0, bottom: 0,
                  borderLeft: '1px solid var(--line)' }}>
                  <div style={{ position: 'absolute', top: 4, left: 4, fontSize: 10.5,
                    color: 'var(--ink-4)', fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--font-mono)' }}>
                    0:{String(s).padStart(2,'0')}
                  </div>
                </div>
              ))}
              {/* waveform */}
              <svg style={{ position: 'absolute', left: 0, top: 22, width, height: headerH - 24, overflow: 'visible' }}
                viewBox={`0 0 ${width} ${headerH - 24}`} preserveAspectRatio="none">
                {WAVE.map((v, i) => {
                  const x = (i / WAVE.length) * width;
                  const h = v * (headerH - 30);
                  const y = (headerH - 24) / 2;
                  return <line key={i} x1={x} x2={x} y1={y - h/2} y2={y + h/2}
                    stroke="oklch(70% 0.08 var(--accent-h))" strokeWidth={width / WAVE.length}/>;
                })}
              </svg>
              {/* downbeat markers */}
              {DOWNBEATS.filter(b => b <= total).map((b, i) => (
                <div key={i} style={{ position: 'absolute', left: b * pxPerSec, top: 18, bottom: 0,
                  borderLeft: '1.5px solid color-mix(in oklab, var(--accent), white 35%)', pointerEvents: 'none' }}>
                  <div style={{ position: 'absolute', top: 0, left: 2, fontSize: 9, fontWeight: 600,
                    color: 'var(--accent-700)', fontFamily: 'var(--font-mono)' }}>{i+1}</div>
                </div>
              ))}
              {/* beat markers (subtler) */}
              {BEATS.filter(b => b <= total && DOWNBEATS.indexOf(b) === -1).map((b, i) => (
                <div key={i} style={{ position: 'absolute', left: b * pxPerSec, top: 30, bottom: 4,
                  borderLeft: '1px solid color-mix(in oklab, var(--accent), white 65%)', pointerEvents: 'none' }}/>
              ))}
              {annotations && (
                <span className="pin" style={{ left: 220, top: 8 }}>1
                  <span className="tip">Beat markers — every kick is detected and snapped to. Downbeats numbered.</span>
                </span>
              )}
            </div>
          </div>

          {/* tracks */}
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {TRACKS.map((tr, ti) => (
              <div key={tr.id} style={{ display: 'flex', borderBottom: '1px solid var(--line)',
                background: ti % 2 === 0 ? 'var(--surface)' : 'var(--panel)' }}>
                <div style={{ width: labelW, padding: '0 12px', display: 'flex', alignItems: 'center',
                  borderRight: '1px solid var(--line)', flexShrink: 0,
                  background: ti % 2 === 0 ? 'var(--surface)' : 'var(--panel)', position: 'sticky', left: 0, zIndex: 2 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tr.name}</div>
                    <div style={{ fontSize: 10.5, color: 'var(--ink-4)' }}>{tr.count}</div>
                  </div>
                  <button className="btn ghost sm" style={{ padding: '2px 6px', fontSize: 10, height: 22 }} title="Solo">S</button>
                  <button className="btn ghost sm" style={{ padding: '2px 6px', fontSize: 10, height: 22 }} title="Mute">M</button>
                </div>
                {/* track lane */}
                <div style={{ position: 'relative', height: rowH, width, flexShrink: 0 }}>
                  {/* light beat grid */}
                  {DOWNBEATS.filter(b => b <= total).map((b, i) => (
                    <div key={i} style={{ position: 'absolute', left: b * pxPerSec, top: 0, bottom: 0,
                      borderLeft: '1px solid color-mix(in oklab, var(--line), white 30%)', pointerEvents: 'none' }}/>
                  ))}
                  {/* effect blocks */}
                  {SEQ.filter(s => s.track === tr.id).map((s, i) => {
                    const left = s.t * pxPerSec;
                    const w = s.d * pxPerSec - 2;
                    const c = fxColor(s.fx);
                    const sty = blockStyleFor(c);
                    return (
                      <div key={i} onClick={(e) => e.stopPropagation()}
                        style={{ position: 'absolute', left: left + 1, top: 4, height: rowH - 8,
                          width: w, borderRadius: 5, padding: '0 7px',
                          display: 'flex', alignItems: 'center', overflow: 'hidden',
                          fontSize: 11, fontWeight: 600, cursor: 'grab',
                          boxShadow: '0 1px 2px rgba(20,22,28,.12)',
                          ...sty }}>
                        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{fxName(s.fx)}</span>
                      </div>
                    );
                  })}
                  {annotations && tr.id === 'megaTree' && (
                    <span className="pin" style={{ left: 90, top: -2 }}>2
                      <span className="tip">Effect blocks. Drag horizontally to move, edges to resize. Snaps to beats.</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* playhead */}
          <div style={{ position: 'absolute', left: labelW + time * pxPerSec, top: 0, bottom: 0,
            width: 2, background: 'var(--xmas-red)', pointerEvents: 'none', zIndex: 4 }}>
            <div style={{ position: 'absolute', top: -2, left: -6, width: 14, height: 14,
              background: 'var(--xmas-red)', borderRadius: '50% 50% 50% 0', transform: 'rotate(-45deg)'}}/>
          </div>
        </div>
      </div>
    </div>
  );
};

window.Timeline = Timeline;
