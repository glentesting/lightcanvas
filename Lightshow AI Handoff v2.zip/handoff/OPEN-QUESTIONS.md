# Open questions to resolve before / during implementation

Things the design + prototype don't fully answer. Surface to the user when you hit them.

## Audio
- Max audio file length / size? (Suggest: cap at 15 min, 30MB. Christmas songs are 3–5min.)
- Multi-song shows? (Out of scope v1.)
- Audio re-analysis trigger if user replaces the song? (Yes, blow away `audio` and re-run.)
- Audio output during live shows: PC speakers only in v1? FM transmitter / Bluetooth speaker via Bridge in v1.1.

## Fixtures
- Can a fixture belong to multiple groups? (Suggest: no, simpler.)
- Pixel order: clockwise or strand-direction? Some users wire arches L→R, some R→L. (`reversed` flag added in `11-hardware-bridge.md`.)
- DMX-style heads (moving lights, RGBW)? (Out of scope v1 — `pixelOrder` field includes RGBW so the data model survives.)

## Timeline
- Per-track effect layering (multiple stacked effects on one track at the same time)? Prototype shows single-layer; xLights supports multi-layer. (Decide before shipping — I'd suggest single layer in v1, "Add layer" feature later.)
- Looping a region during playback? (Nice-to-have, not in v1 acceptance.)

## AI
- Token budget when we swap to real Claude — how many beats can we send? (At 140 BPM × 3min that's ~420 beats; well under any context limit. But effect-block output for a full song could be 100s of blocks — stream them, don't generate all at once.)
- Caching: re-running "Generate from Music" with same inputs should cache. Use Vercel KV or just a Supabase `ai_generations` table.

## Exports
- xLights `.fseq` binary export — defer to v2, but document in 09-exports.md. Some users need it directly.
- MP4 vs WebM: ffmpeg.wasm is ~25MB. Lazy-load only when user picks MP4. Acceptable?
- Hardware export (controller-direct via `.eseq` for Falcon controllers)? Way out of scope.

## Hardware (`11-hardware-bridge.md`)
- Tauri vs Electron for Bridge? Tauri preferred for size; Electron has more battle-tested UDP examples. Confirm with the user before slice 11.
- Auto-update channel for Bridge: ship stable + beta? Single stable in v1.
- How do we handle a user with **two laptops** that both want to be Bridge for the same project? Spec says one Bridge per schedule; UI needs to enforce.
- Mirror-to-lights latency target ≤80ms is aspirational on poor Wi-Fi. Acceptable degradation?
- DDP/Art-Net stubs in v1 vs full v1 implementation? Currently scoped as v1.1.

## Mobile (`14-mobile-responsive.md`)
- iOS PWA push notifications were limited until iOS 16.4. v1 minimum: best-effort with email fallback for show-failure events.
- Should the Show Remote allow editing schedules, or only run-time controls? (v1: run-time only.)

## Settings / billing (`15-settings-account.md`)
- Free vs paid tier specifics — deferred per user.
- Storage quota for free tier — placeholder 500MB, revisit before billing ships.
- Team plans: how many seats per plan? Per-bridge billing or per-user? Defer until v2.

## Telemetry (`18-telemetry.md`)
- Self-host PostHog vs hosted? Hosted in v1, revisit at scale.
- Sentry session replay sample rate — currently 0% normal, 100% on error. Tune after first month of data.

## Legal (`19-legal.md`)
- Audio rights checkbox at upload — strong enough for our liability posture? Confirm with counsel before launch.
- DMCA email account — `dmca@lumen.app` — set up actual mailbox + monitoring.
- COPPA: do we need an explicit age gate above what Clerk provides? Probably not for v1.

## Other
- Mobile editor: blocked with redirect in v1. Read-only Preview-only view is built. Sharing public-read `/p/[shareToken]` is v2.
- Collaborative editing: Hard nope for v1.
- Sharing: public read-only project view at `/p/[shareToken]`? Common ask, not in v1 spec.
