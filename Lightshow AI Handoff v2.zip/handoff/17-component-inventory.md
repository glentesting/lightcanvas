# 17 — Component Inventory & Variants

The prototype uses many small primitives consistently — buttons, chips, sliders, the
fixture pill, the effect block, the empty state. Without an inventory, two developers
will rebuild them four different ways. This file is the canonical list. Each entry
points to where it should live in the repo and what variants exist.

> If a primitive isn't listed here, **don't invent one.** Either compose from these
> or discuss with the user before adding.

## Where things live

```
components/
  ui/                        # shadcn primitives (already there)
    button.tsx               # — see Variants below
    input.tsx
    dialog.tsx
    popover.tsx
    dropdown-menu.tsx
    context-menu.tsx
    tooltip.tsx
    tabs.tsx
    slider.tsx
    switch.tsx
    radio-group.tsx
    select.tsx
    sheet.tsx                # bottom sheets on mobile
    progress.tsx
    skeleton.tsx
    badge.tsx
    avatar.tsx
    label.tsx
    accordion.tsx
    toast.tsx
  lumen/                     # our app primitives
    page-header.tsx          # title + subtitle + right-aligned actions
    section-card.tsx         # bordered card with optional collapse
    empty-state.tsx          # illustration + headline + body + CTA(s)
    error-state.tsx          # same shape, for error
    loading-state.tsx        # skeleton wrapper
    color-swatch.tsx         # inline color swatch — square, hex tooltip
    color-picker.tsx         # full picker (popover) — hex, swatch row, eyedropper
    fixture-icon.tsx         # 6 inline SVGs from icons.jsx in prototype
    fixture-pill.tsx         # icon + name + pixel count, in sidebar
    effect-chip.tsx          # palette chip — color dot + label + kbd hint
    effect-block.tsx         # timeline block — see Variants below
    timeline-ruler.tsx       # numbered downbeats + tick marks
    playhead.tsx             # vertical line + handle, scrubbable
    audio-waveform.tsx       # WaveSurfer container
    audio-progress.tsx       # for analysis state — labeled bar
    status-pill.tsx          # online/offline/error indicator
    kbd.tsx                  # keyboard shortcut hint, mono small
    user-menu.tsx            # avatar dropdown
    breadcrumb.tsx           # back arrow + chain
    save-indicator.tsx       # "Saved" / "Saving" / "Couldn't save"
    house-svg.tsx            # the stylized house from the prototype
```

---

## Variants

### Button (`components/ui/button.tsx` — extend shadcn)

| Variant | When to use |
|---|---|
| `primary` | One per surface. Sky-blue fill, white text. |
| `secondary` | Bordered, surface fill. Most actions. |
| `ghost` | No fill. Inline / quiet actions. |
| `destructive` | Red, only for irreversible actions. |
| `link` | Text link, underline on hover. |

Sizes: `sm` 28px, `default` 34px, `lg` 42px. Icon-only versions: `icon-sm`,
`icon`, `icon-lg`. Always pair icon-only with `aria-label`.

### Empty state (`components/lumen/empty-state.tsx`)

```tsx
<EmptyState
  illustration="dark-house"     // string id from a small registry
  headline="No shows yet"
  body="Create your first show in two minutes."
  primaryAction={{ label: 'Start a new show', onClick }}
  secondaryAction={{ label: 'Try the demo song', onClick }}
/>
```

Illustration registry lives in `components/lumen/illustrations/`. SVG-only, warm
palette. Keep tightly bounded — 5–8 illustrations max for v1.

### Effect block (`components/lumen/effect-block.tsx`)

States: `idle`, `hover`, `selected`, `dragging`, `resizing`, `locked`, `error`.

- Idle: tinted bg from effect color (`fx-{id}` Tailwind), 1px border
- Hover: ring 1px accent
- Selected: ring 2px accent, brighter bg
- Dragging: 80% opacity, no shadow (avoids drag-shadow weight)
- Resizing: drop shadow on the resize edge
- Locked: padlock icon, no resize handles
- Error (channel conflict): amber border, warning icon

### Color picker

Opens a popover with:
- 12 swatches across two rows (warm + cool sets, plus the fx palette)
- Hex input
- Eye-dropper button (Chrome/Edge `EyeDropper` API; hide on Safari/Firefox)
- "Recent colors" — last 5 used

Single source of truth for all color editing. Used in effect properties, fixture
defaults, schedule themes (v2), and brand customization.

### Status pill

States: `online` (green dot), `offline` (gray), `error` (red), `warning` (amber),
`paused` (blue). Single line of text follows.

---

## Tokens (cross-reference)

All visual primitives consume CSS variables from `app/globals.css` (already in
`10-design-system.md`). When adding a new token:

1. Add to `:root` in globals.css with `--name`
2. Add to `tailwind.config.ts` colors/space/radius
3. Document in this file

Don't bake hex codes into components. The prototype's accent-h variable retints
the entire app — keep that working.

---

## Storybook (recommended, not required)

If time allows: spin up Storybook with one story per component above and one story
per variant. Most useful for `effect-block`, `fixture-pill`, `empty-state`,
`color-picker`. If we skip Storybook, write a private route `/dev/components`
that mounts every primitive in every state for visual review.

---

## Acceptance

- [ ] Every screen in the app uses primitives from this inventory only
- [ ] Adding a new color in `:root` retints all primitives that depend on it
- [ ] No hardcoded hex codes in `components/lumen/*`
- [ ] Empty/error/loading states use the dedicated primitives, not bespoke divs
- [ ] Buttons across the app share the same height + padding rhythm
