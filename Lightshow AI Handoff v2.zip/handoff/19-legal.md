# 19 — Legal: Terms, Privacy, Copyright, Data Deletion

The prototype shipped with no legal pages. Don't ship the product that way. This
file enumerates the legal surfaces the product needs and how they connect to the
data model. **Have a real lawyer review the actual document text** — these are
specs for behavior, not legal advice.

## Required pages

- **`/legal/terms`** — Terms of Service. What the user agrees to. Acceptable use,
  warranty disclaimers, jurisdiction.
- **`/legal/privacy`** — Privacy Policy. What we collect, why, how long, who we
  share with, user rights.
- **`/legal/cookies`** — Cookie policy. Reachable from the cookie banner.
- **`/legal/copyright`** — DMCA-style policy + audio-rights notice (see below).
- **`/legal/security`** — Security overview, vulnerability disclosure email.
- Footer link to all of the above on every public page.

## Audio copyright (the big one)

Lumen lets people upload their own MP3s. They might upload music they don't have
rights to. We need to be clear about this.

### Posture
- We do **not** review uploaded audio.
- We do **not** publicly distribute uploaded audio. It's stored privately, served
  via signed URLs to the owner, played from Bridge to the owner's hardware.
- The owner is solely responsible for ensuring they have rights to play the song
  in their show.
- Public sharing of a project (v2 feature) **excludes the audio file**. Shared
  projects show the song's title only and direct viewers to source the audio
  themselves.

### What to display
- Upload modal includes a checkbox: "I have rights to use this audio in my show."
  Required. Persisted on the audio record.
- Acceptable Use Policy in the Terms references this explicitly.
- Marketing copy never implies users can play licensed music in public — say
  "your audio" not "your favorite Christmas songs."

### DMCA workflow
- `dmca@lumen.app` listed on `/legal/copyright`
- Standard takedown form: complainant contact, identification of work, identification
  of allegedly infringing content (project ID), good-faith statement
- On valid notice: lock the audio file in the affected project, notify the user,
  provide counter-notice flow
- Repeat-infringer policy: terminate accounts after 3 valid takedowns

## Privacy / data export / deletion (GDPR + CCPA)

### Right to access
Settings → Account → "Download my data" → server action that:
1. Streams a ZIP file with:
   - `account.json` — profile fields
   - `projects.json` — every project
   - `audio/` — original audio files
   - `controllers.json` — controller config
   - `schedules.json`, `runs.json`
   - `events.csv` — PostHog events about this user (if any)
2. Email when ready (large exports may take >30s; do it async via background job)

### Right to deletion
Already specified in `15-settings-account.md` as the Delete Account flow. 14-day
grace period, then hard cascade delete + Storage purge.

### Right to rectification
Editing profile in Settings → Account covers it.

### Subprocessors list
On `/legal/privacy`, list:
- Clerk (auth)
- Supabase (database, storage)
- Vercel (hosting)
- Sentry (error monitoring)
- PostHog (analytics)
- Anthropic (AI features — when we ship real AI)
- Stripe (when billing ships)

Each with: purpose, data shared, location.

### Data residency
v1 is US-only (Supabase + Vercel US regions). EU residency is v2. Disclose this
in privacy policy; offer EU users US-resident option with informed consent.

### Children
Not directed at children under 13. Block COPPA-flagged accounts from being created
(Clerk handles age gate).

## Cookie banner

shadcn-styled non-modal bottom-anchored banner on first visit. Three buttons:
- **Accept all** — analytics + necessary
- **Reject all** — necessary only
- **Customize** — opens a panel with toggles per category

Categories: Necessary (always on), Analytics (PostHog), Functional (preferences).
Sentry treated as Necessary, disclosed transparently. Persist choice in a
`lumen_consent` cookie + `localStorage`.

## Bridge software license

Bridge desktop app ships under a EULA distinct from the cloud Terms. Standard
clauses:
- License grant tied to active Lumen account
- No reverse engineering / redistribution
- We may push auto-updates
- Telemetry opt-in (see `18-telemetry.md`)

Display the EULA on first launch with Accept; persist version + timestamp.

## Open-source attributions

Every dependency we ship — wavesurfer, meyda, dnd-kit, etc — needs license
attribution. Auto-generate via `license-checker` on each build into
`/legal/oss-licenses` so we don't drift.

---

## Acceptance

- [ ] All five `/legal/*` pages exist with placeholder copy clearly marked as
  "Awaiting legal review"
- [ ] Cookie banner appears on first visit, persists choice, respects DNT
- [ ] PostHog does not load until consent; Sentry loads always (necessary)
- [ ] Audio upload requires checkbox; checkbox state stored on the file record
- [ ] DMCA email is monitored and surfaces in Settings → Notifications for admin
  accounts
- [ ] Data export delivers a real ZIP with all of the user's content within 1 hour
- [ ] Delete Account fully removes data after the 14-day grace period; verified
  via DB inspection
- [ ] OSS licenses page renders all production dependencies
