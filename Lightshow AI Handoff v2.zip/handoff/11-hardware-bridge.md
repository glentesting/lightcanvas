# 11 — Hardware Bridge: Controllers, Props, Protocols, Live Playback

This is the doc the prototype couldn't show. Lumen is a sequence designer, but the
sequences only matter if they actually drive real lights on a real house. This file
covers what's between Lumen and the LEDs.

> **Scope:** v1 ships with two paths. (a) **Export to xLights** — the user runs xLights
> locally, xLights talks to their controllers. This is the safe default and is already
> covered in `09-exports.md`. (b) **Lumen Bridge** — a small local app that plays a
> sequence directly from Lumen's web UI to the user's controllers over their LAN. This
> doc specifies (b). Direct browser-to-controller is **not viable** (browsers can't open
> raw UDP sockets, can't hold a 40fps real-time loop reliably, and can't see the user's
> LAN from the cloud).

---

## The chain, end to end

```
[Browser editor]  ──HTTPS──▶  [Lumen cloud API]
                                    │
                                    │  (sequence + audio + show triggers)
                                    ▼
[Lumen Bridge desktop app]  ◀──WebSocket / local relay──┐
        │                                               │
        │ E1.31 (sACN) UDP, DDP, or Art-Net             │
        ▼                                               │
[User's WLED / Falcon / Pixlite controllers]            │
        │                                               │
        ▼                                               │
[Real LED strands on the house]                         │
                                                        │
[Mobile "Show Remote" PWA]  ──HTTPS──▶  [cloud API]  ───┘
```

Three pieces:

1. **Lumen Cloud** — what we're building. Holds the project, generates the sequence
   payload, brokers commands to the bridge.
2. **Lumen Bridge** — small Electron / Tauri app the user installs on a Windows or Mac
   PC that's on the same Wi-Fi as their controllers. It logs into the user's Lumen
   account and pairs with one or more projects. Receives "play this sequence at HH:MM"
   commands and streams DMX/E1.31 frames at 40fps.
3. **Controllers** — third-party hardware (WLED, Falcon F16v4, Pixlite, AlphaPix, etc.)
   the user already owns. We don't ship hardware.

---

## Protocols (what Bridge speaks)

| Protocol | What it is | When to use |
|---|---|---|
| **E1.31 / sACN** (UDP, port 5568, multicast 239.255.0.x) | The xLights/lighting industry standard. Each "universe" = 512 channels. RGB pixel = 3 channels. | **Default.** Almost every consumer pixel controller speaks this — Falcon, Pixlite, AlphaPix, K16/32, Hinkspix. |
| **DDP** (UDP, port 4048) | Lower-overhead pixel protocol used by WLED and some Falcons. | Use when controller advertises DDP — saves bandwidth on big shows. |
| **Art-Net** (UDP, port 6454) | Older theatrical lighting standard. | Fallback if user's controller is Art-Net only. |
| **WLED HTTP/JSON** | WLED's own REST API. | For users with only WLED strips, no e1.31 setup needed — Bridge talks JSON to each WLED IP. |

v1 implements **E1.31** + **WLED JSON**. Art-Net and DDP are stubbed behind the same
`OutputDriver` interface and shipped in v1.1.

```ts
// bridge/src/output/driver.ts
export interface OutputDriver {
  id: 'e131' | 'ddp' | 'artnet' | 'wled-http';
  start(): Promise<void>;
  sendFrame(universe: number, channels: Uint8Array): void;  // 512 bytes per universe
  stop(): Promise<void>;
}
```

The renderer (same `lib/render/engine.ts` from `07-preview-engine.md`) runs inside
Bridge at 40fps, produces `Map<fixtureId, RGB[]>`, the channel mapper packs those into
universes per the user's fixture config, and the driver fires UDP packets.

---

## Channel mapping

Already partly defined in `06-fixtures-and-layout.md` (`startChannel`,
`pixelCount * 3`). Extend the `Fixture` type:

```ts
// lib/fixtures/types.ts — addition
export interface Fixture {
  // …existing fields
  controllerId?: string;          // FK to Controller (Bridge config)
  universe?: number;              // E1.31 universe (1..63999)
  startChannel: number;           // 1..512 within the universe
  pixelOrder?: 'RGB' | 'GRB' | 'BGR' | 'RGBW';  // strands vary
  reversed?: boolean;             // strand direction flip
}
```

`startChannel + pixelCount * 3` must fit in one universe (≤512); if it doesn't, the
fixture spans multiple universes (continuing at channel 1 of universe+1). The Add
Fixture dialog and a "Channel map" view in Bridge help users see the full layout.

---

## Controller model

```ts
// lib/hardware/types.ts
export type ControllerKind = 'falcon' | 'pixlite' | 'alphapix' | 'wled' | 'k16' | 'hinkspix' | 'generic-e131';

export interface Controller {
  id: string;
  ownerId: string;
  name: string;                   // user label, e.g. "Garage controller"
  kind: ControllerKind;
  ipAddress: string;              // LAN IP — discovered or manual
  protocol: 'e131' | 'ddp' | 'artnet' | 'wled-http';
  universes: number[];            // which universes this controller listens for
  status: 'online' | 'offline' | 'error';
  lastSeenAt?: string;
  firmwareVersion?: string;
}
```

These live on the cloud DB so they show up in the editor's "Layout" tab and on the
mobile remote — but Bridge is the only thing that actually pings them.

---

## Lumen Bridge — desktop app

### Stack
- **Tauri** (preferred) or Electron — Tauri is ~10MB vs Electron ~120MB and crucial for
  a "your grandparents can install this" download. Rust backend handles UDP sockets +
  realtime loop; webview UI in React.
- Auto-updates via Tauri's built-in updater pointing at `releases.lumen.app`.

### What Bridge does on launch
1. Sign in with the same Clerk credentials used on lumen.app (OAuth device-code flow,
   so the user pastes a 6-digit code into the web app).
2. Discover controllers on the LAN:
   - **mDNS** for WLED (`_wled._tcp`) — gets you IP + name.
   - **E1.31 universe discovery** ping (poll multicast group 239.255.0.1).
   - **Manual add** as a fallback (IP, kind, universe range).
3. Persist controller config locally in `~/Library/Application Support/Lumen/bridge.db`
   (SQLite) **and** mirror to the cloud DB so the editor knows which controllers exist.
4. Open a WebSocket to `wss://api.lumen.app/bridge/v1` and announce online status.

### What Bridge does at show time
- Receives a `RunSequenceCommand`:
  ```ts
  type RunSequenceCommand = {
    type: 'run-sequence';
    projectId: string;
    audioUrl: string;        // signed URL — Bridge downloads + caches locally
    sequencePayload: SerializedSequence;
    fixtureMap: Fixture[];
    startAt: string;         // ISO datetime — Bridge schedules; allows "play at 6:00pm"
    loop?: boolean;
  };
  ```
- Pre-rolls: downloads audio (cached by `sha256(audioUrl)`), validates fixtures map to
  known controllers, primes a 1s ring buffer of frames.
- Plays:
  - Audio plays on the PC (so the user hears it in their garage); a future v1.1 adds
    audio-over-FM-transmitter setups.
  - Render loop: `setInterval` at 25ms (40fps) → render engine → channel pack → driver
    `sendFrame(universe, bytes)` per universe.
  - If a frame is dropped, log it and skip — never queue ahead of audio (drift).
- Stops on command, end-of-song, or controller error.

### Heartbeat & status
Bridge posts `{ status, currentTime, controllers: [...] }` to the cloud every 2s while
playing. The mobile remote and the desktop editor read this stream over SSE so users
can monitor a running show.

---

## Editor changes for hardware

The Layout view (`06-fixtures-and-layout.md`) gains:

- **Controllers panel** — collapsible section in the sidebar listing user's controllers
  (status dot · name · ip · universes used). "+ Add controller" opens a dialog with
  Discover / Manual tabs.
- **Per-fixture controller picker** — Properties panel adds Controller / Universe /
  Start channel / Pixel order. Validation: warn on overlap, hard-block on impossible
  configs (e.g. universe out of range).
- **"Test fixture" button** — sends a 3-second rainbow chase to the selected fixture
  via Bridge. Confirms wiring is right before the user spends 30 minutes designing a
  show against a fixture wired backward.

The Preview tab gains a **"Mirror to lights"** toggle. When on, every preview frame is
also sent to Bridge over the WebSocket — design with real lights as feedback. Latency
target: ≤80ms RTT on a same-LAN setup.

---

## Show scheduling

Real users don't sit at a laptop and click play at 6pm every night. They want
"Wizards in Winter at 7:15pm, every night Dec 1–Jan 5, on/off automatic."

```ts
// lib/scheduling/types.ts
export interface ShowSchedule {
  id: string;
  ownerId: string;
  projectId: string;
  // When to play
  rrule: string;               // RFC 5545 RRULE: "FREQ=DAILY;BYHOUR=19,20;BYMINUTE=15"
  startDate: string;           // YYYY-MM-DD
  endDate: string;
  // Behavior
  loopWithin?: { startMin: number; endMin: number };  // loop the song between 7:15–8:30
  weatherSkip?: 'rain' | 'snow' | 'none';             // skip on bad weather (v1.1)
  // Bridge that runs it
  bridgeId: string;
}
```

A "Schedules" tab in the dashboard lists upcoming shows and recent runs. Bridge
subscribes to its assigned schedules and runs them locally — even if the user's
laptop browser is closed.

---

## Failure modes

The single biggest source of user pain. Spec each failure with a state name, what the
user sees, and the recovery path.

| Failure | State | UX |
|---|---|---|
| Bridge offline at show start | `bridge:disconnected` | Push notification + dashboard banner: "Bridge couldn't be reached. Show was skipped at 7:15pm." Action: "Open Bridge" deep-link. |
| Controller unreachable mid-show | `controller:dropped` | In-show toast + recorded incident on schedule's Run record. Lights on that controller go dark; rest of show continues. |
| Universe overlap detected | `config:overlap` | Block the affected fixture from playing; flag at Layout time before the user ever runs. |
| Audio out of sync (drift > 200ms) | `sync:drift` | Bridge force-resyncs — pauses 50ms, re-zeros to audio's current position. Logged. |
| WebSocket disconnect | `cloud:offline` | Bridge keeps playing locally from cached payload. Cloud sees grey "unknown" status until WS reconnects. |
| Audio file 404 (signed URL expired) | `audio:404` | Bridge refetches a fresh signed URL via REST before giving up. |
| Pixel count mismatch (user changed strand without updating fixture) | `fixture:mismatch` | Detected by Bridge's "Test fixture" — surfaces in Properties panel. Doesn't auto-correct (could damage strands). |

Every failure logs to `show_runs` table:

```sql
create table public.show_runs (
  id uuid primary key default gen_random_uuid(),
  schedule_id uuid references show_schedules(id) on delete cascade,
  bridge_id uuid not null,
  started_at timestamptz not null,
  ended_at timestamptz,
  outcome text not null,            -- 'completed' | 'failed' | 'skipped' | 'partial'
  failure_code text,                -- one of the state names above
  failure_detail jsonb,
  frames_dropped int default 0
);
```

Dashboard surfaces "Last run: success · 3min ago" or "Last run: failed · check
controllers."

---

## Acceptance

- [ ] User installs Bridge, signs in, sees their cloud projects listed
- [ ] Bridge auto-discovers a WLED on the LAN; user adds it; appears in editor
- [ ] User clicks "Test fixture" on a roofline strip — strand runs a 3s rainbow chase
- [ ] User mirrors the Preview tab to real lights; visible latency ≤100ms on LAN
- [ ] User schedules a show for 5 minutes from now; Bridge runs it; lights play in sync with audio
- [ ] User powers off the controller mid-show; show continues on remaining fixtures, dashboard shows partial-run record with `controller:dropped`
- [ ] User signs out of Bridge; cloud immediately marks bridge offline; scheduled show 1 minute later is recorded as `skipped` with a notification
