# Ready-to-paste Claude Code prompts

Each prompt is a self-contained instruction for one slice. Paste into Claude Code one at a time, in order. Wait for it to finish + verify locally before moving to the next.

Each one assumes the existing scaffold (Next.js 14 App Router, TypeScript, Tailwind, shadcn, Clerk, Supabase) is already running.

---

## Prompt 0 — Read the plan

```
Read the entire `handoff/` folder in this repo, starting with CLAUDE.md, then 00 through 19 in order, then OPEN-QUESTIONS.md and CORRECTION-layout-tab.md. After reading, summarize the architecture in 5 bullets and tell me which slice you'd start with. Don't write any code yet.
```

## Prompt 1 — Supabase schema

```
Implement handoff/01-supabase.md. Create the migration files under supabase/migrations/, run them locally against the dev project, and regenerate lib/supabase/types.ts. Verify RLS by running the manual checks listed in the Acceptance section. Show me the migration SQL before applying.
```

## Prompt 2 — Domain types & folder skeleton

```
Implement handoff/00-architecture.md. Create the empty folders + the canonical TypeScript domain types from that file (lib/timeline/types.ts, lib/fixtures/types.ts, lib/audio/types.ts, types/domain.ts). Don't implement any logic yet — just the types and folder structure with index.ts re-exports.
```

## Prompt 3 — Dashboard + project CRUD

```
Implement handoff/02-projects-and-dashboard.md. Build the dashboard page, project card, new-project dialog, and the four server actions (create/delete/rename/duplicate). Match the prototype's visual style — see Lumen Prototype.html in this repo for reference. Hit every Acceptance bullet before stopping.
```

## Prompt 4 — Editor shell, store, autosave

```
Implement handoff/03-editor-shell.md. Set up the Zustand store with zundo for undo/redo, the transport store, autosave to /api/projects/[id]/autosave, and the EditorShell + TopBar + Sidebar components. Don't implement timeline interactions yet — just the shell and a placeholder timeline area. URL-driven tabs.
```

## Prompt 5 — Audio engine

```
Implement handoff/04-audio-engine.md. Wire up the upload flow (signed URLs to lumen-audio bucket), the WaveSurfer instance inside the editor, and the Meyda-based beat detection in a Web Worker. After analysis, persist `audio` to the project and render beat markers + numbered downbeats as an SVG overlay above the waveform. Press space toggles play.
```

## Prompt 6 — Timeline interactions

```
Implement handoff/05-timeline.md. This is the biggest slice — go in this order: render existing blocks → drag from palette → drag existing blocks → resize → multi-select → context menu → keyboard shortcuts → parameter panel. Cmd+Z must work end-to-end. Stop and confirm with me after drag-from-palette is working.
```

## Prompt 7 — Fixtures + Layout view

```
Implement handoff/06-fixtures-and-layout.md. Build the Layout tab: fixture list, house SVG with anchor regions, drag-to-place flow for both strand and point fixtures. Add the "+ Add fixture" dialog. Persist `layout.points` and verify they survive a refresh.
```

## Prompt 8 — Preview engine

```
Implement handoff/07-preview-engine.md. Build the pure render engine in lib/render/, all 10 effect functions, and both renderers (SVG default + canvas fancy). Wire the Preview tab to read transport.currentTime and re-render. Test with the demo "Wizards in Winter" project (seed it from the prototype's editor-data.jsx).
```

## Prompt 9 — AI panel (mock)

```
Implement handoff/08-ai-panel.md. Build the panel UI matching the prototype, the AIProvider interface, the MockAIProvider, and the SSE-streaming /api/ai/* routes. The mock should produce plausible output by composing effects against the song's beats. Wrap each AI run in a single undo entry.
```

## Prompt 10 — Exports

```
Implement handoff/09-exports.md. Build all three exporters. For xLights, target the 2024 .xsq XML format. Create a fixture model + 30 seconds of effects, export, open the .xsq in xLights locally, and verify it loads with effects on the right models at the right times. Iterate the settings strings until it works.
```

## Prompt 11 — Design polish pass

```
Implement handoff/10-design-system.md. Translate the prototype's styles.css into Tailwind config + globals.css + shadcn theme overrides. Walk every screen and confirm it matches the prototype: dashboard, editor, AI panel, export dialog, onboarding. Light mode only — no dark dropdowns or modal overlays.
```

## Prompt 12 — Hardware Bridge (desktop app)

```
Implement handoff/11-hardware-bridge.md. Scaffold the Bridge desktop app as a separate Tauri project under `bridge/` (or Electron if Tauri can't hit E1.31 reliably — flag and decide with me first). Implement the OutputDriver interface, an E1.31 driver, and a WLED HTTP driver. Pair with the cloud via OAuth device-code flow. Add the `controllers` table + RLS. Add the cloud-side WebSocket gateway at /bridge/v1. Don't implement scheduling yet — just real-time mirror.
```

## Prompt 13 — Operator onboarding wizard

```
Implement handoff/12-onboarding-hardware-setup.md. Add the branching onboarding (designer vs operator), the 6-step hardware wizard, controller discovery UI, fixture-to-controller mapping, and the test-fixture flow. The wizard must work end-to-end: brand-new user → Bridge installed → controller discovered → roofline strip runs a rainbow chase.
```

## Prompt 14 — Empty / loading / error states

```
Implement handoff/13-states-empty-loading-error.md. Walk every screen in the app and add the three states. Use the dedicated primitives from 17-component-inventory.md (EmptyState, ErrorState, LoadingState). Verify with the explicit acceptance checks at the bottom of file 13 — at least the autosave-failure, audio-too-large, and offline-banner cases.
```

## Prompt 15 — Mobile + Show Remote

```
Implement handoff/14-mobile-responsive.md. Make the marketing landing, dashboard, auth, onboarding, and settings fully responsive to ≥360px. Add the editor mobile-block redirect with the "Open Show Remote" CTA. Build /remote as the mobile-first PWA with status header, transport, schedule list, panic stop. Wire up screen-wake-lock and PWA manifest. Lighthouse mobile ≥ 90 on landing + remote.
```

## Prompt 16 — Settings + delete account

```
Implement handoff/15-settings-account.md. Build the /settings nested routes, account section with profile + sessions + delete-account flow (14-day grace), hardware section (reuses Bridge UI from prompt 12), schedules list with run history, and the placeholder billing route. No Stripe imports yet — billing copy only.
```

## Prompt 17 — Schedules + show runs

```
Add the show_schedules and show_runs tables (extending 01-supabase.md). Build the schedule editor (RRULE + bridge picker), the schedule list in /settings/schedules, and Bridge's local scheduler that subscribes via WebSocket. Wire failure events end-to-end: pull a controller's power mid-show, dashboard surfaces the failed run with the correct failure_code.
```

## Prompt 18 — Accessibility + perf gating

```
Implement handoff/16-accessibility-perf.md. Add focus-visible rings everywhere, skip-to-content link, prefers-reduced-motion handling, and aria labels for the timeline + playhead + fixtures + AI panel events. Wrap the marketing hero animation in IntersectionObserver + reduced-motion + visibilityState, with a static SVG fallback. Wire Lighthouse CI on PRs. Add bundle-size budgets and fail builds on regression.
```

## Prompt 19 — Telemetry + monitoring

```
Implement handoff/18-telemetry.md. Wire Sentry browser + server, PostHog with consent gating, Vercel Web Analytics. Cookie banner with three actions (accept all / reject all / customize). Dispatch the activation funnel events (signup_completed, onboarding_completed, first_audio_uploaded, first_effect_added, first_export, first_show_run). Verify no PII leaks via network inspection.
```

## Prompt 20 — Legal pages + data export/deletion

```
Implement handoff/19-legal.md. Build /legal/* pages (terms, privacy, cookies, copyright, security) with placeholder copy clearly flagged "Awaiting legal review." Add the audio-rights checkbox to upload. Build the "Download my data" server action that streams a ZIP with the user's full data. Wire delete-account to actually cascade after the grace period (cron job on Vercel).
```

## Prompt 21 — Smoke test

```
Run a full end-to-end manual test on a real account:
1. Sign up, complete designer onboarding, land on dashboard
2. Create a project from the demo starter
3. Upload an MP3, wait for analysis
4. Drag two effects on, multi-select them, resize, undo
5. Run AI Generate
6. Switch to Layout, place fixtures
7. Switch to Preview, hit play
8. Export Lumen JSON, xLights .xsq, and video
9. Sign out, sign back in on a phone, open Show Remote
10. Install Bridge on a Mac/Win machine, run the operator wizard, pair a real WLED or simulator
11. Schedule a show 2 minutes out, verify it runs and lights respond
12. Force a controller failure mid-show, verify the dashboard shows the partial-run record
13. Trigger an autosave failure, verify the indicator goes red and recovers
14. Set OS to prefers-reduced-motion, verify hero static + editor calm
15. Use only the keyboard for a full editing session — no mouse
16. Request data export, verify ZIP arrives with full content
17. Delete account, verify 14-day grace email, verify hard delete after grace
Report every breakage with repro steps and which file(s) own the fix.
```
