# Lumen Handoff Package

This folder is the spec + build plan for **Lumen** — an AI-assisted Christmas-light show designer that competes with xLights on UX. It's intended to be pasted into Claude Code (or used as documentation) to build the real product on top of an existing Next.js + Clerk + Supabase scaffold.

## What's in here

- **CLAUDE.md** — Start here. Project overview, working agreement, definition of done.
- **00-architecture.md** — Folder structure, domain types, state boundaries, routing map.
- **01-supabase.md** — SQL migrations, RLS policies, Storage buckets.
- **02-projects-and-dashboard.md** — `/dashboard` and project CRUD.
- **03-editor-shell.md** — Editor route, Zustand store, undo/redo, autosave.
- **04-audio-engine.md** — WaveSurfer + Meyda beat detection.
- **05-timeline.md** — Drag, resize, snap, multi-select, undo, shortcuts. The big one.
- **06-fixtures-and-layout.md** — Pixel-accurate fixture model + Layout view.
- **07-preview-engine.md** — Real-time renderer, all 10 effects.
- **08-ai-panel.md** — AI Actions panel + mock provider (real provider stubbed for swap-in).
- **09-exports.md** — Lumen JSON, xLights `.xsq`, MP4/WebM preview.
- **10-design-system.md** — Tailwind tokens + shadcn theme to match the prototype.
- **11-hardware-bridge.md** — Lumen Bridge desktop app, controllers, E1.31/DDP/Art-Net/WLED, live playback.
- **12-onboarding-hardware-setup.md** — 6-step Operator wizard (install Bridge, pair, discover, map, test, schedule).
- **13-states-empty-loading-error.md** — Every empty / loading / error state, screen by screen.
- **14-mobile-responsive.md** — Mobile posture per surface + the Show Remote PWA.
- **15-settings-account.md** — Settings IA, account, hardware, schedules, billing placeholder, delete account.
- **16-accessibility-perf.md** — WCAG 2.2 AA, reduced motion, performance budgets, Lighthouse CI.
- **17-component-inventory.md** — Canonical primitive list + variants. Don't invent new ones.
- **18-telemetry.md** — Sentry, PostHog, consent, what we do and don't collect.
- **19-legal.md** — Terms, Privacy, audio copyright + DMCA, GDPR/CCPA data export & deletion.
- **OPEN-QUESTIONS.md** — Things the spec doesn't pin down; flag during implementation.
- **CORRECTION-layout-tab.md** — Targeted fixes to bring the Layout tab back in line with the prototype.
- **prompts/README.md** — Ready-to-paste Claude Code prompts, one per slice.

## How to use

1. Drop this folder into your repo at `docs/lumen-buildplan/` (or wherever).
2. Open Claude Code, point it at the repo, and paste **prompts/README.md**'s Prompt 0.
3. Then paste prompts 1–12 in order. Wait for each to finish and verify locally before moving on.
4. The visual prototype (`Lumen Prototype.html` in the project root) is the visual source of truth — copy it forward.

## Stack reminder

- Existing: Next.js 14 App Router · TypeScript · Tailwind · shadcn/ui · Clerk · Supabase
- Adding: Zustand · WaveSurfer.js v7 · Meyda · dnd-kit · zundo · zod · React Query

## What's intentionally NOT here (v1 scope)

- A full xLights `.fseq` binary writer (deferred to v2 — `09-exports.md`)
- Real Anthropic AI integration — interface set up, mock provider in v1 (`08-ai-panel.md`)
- Real billing — placeholder route + copy only (`15-settings-account.md`)
- DDP and Art-Net protocols — interface set up, E1.31 + WLED in v1 (`11-hardware-bridge.md`)
- `.fseq` and `.eseq` direct controller exports
- EU data residency — US-only in v1, disclosed in privacy policy (`19-legal.md`)
- Multi-user collaboration / team / sharing — placeholder route (`15-settings-account.md`)
- Mobile editing — desktop redirect; mobile gets read-only viewer + Show Remote (`14-mobile-responsive.md`)
- Weather-based show skipping (v1.1)
- Audio-over-FM-transmitter (v1.1)
