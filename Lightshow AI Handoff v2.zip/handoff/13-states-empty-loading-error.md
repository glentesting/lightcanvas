# 13 — Empty / Loading / Error States

The prototype shows happy paths. Real users hit empty databases, slow networks, and
broken inputs constantly. This doc enumerates every state that needs a non-default
treatment, screen by screen. **No screen ships without all three states implemented.**

Visual rule: every empty/loading/error state matches the prototype's warm, light
aesthetic. No spinners on dark overlays, no generic "Something went wrong" plates,
no Lottie spinners. Skeletons use `bg-panel` shimmer. Errors are full-bleed but
recoverable — every error has at least one action button.

---

## Global

### Loading
- **App boot** — full-page warm cream background, centered Lumen logo, subtle pulse.
  Hold for ≤300ms before fading in actual content. Never show on subsequent navs.
- **Route transitions** — top progress bar (1px, accent color) using Next's
  `app/loading.tsx` per route segment. No full-screen blocker.

### Error
- **`app/error.tsx`** — full page: warm cream, illustration of unplugged Christmas
  lights, "We hit a snag" headline, plain-English explainer, [Try again] [Back to
  dashboard]. Auto-reports to error monitoring. Includes an event ID the user can
  paste into a support email.
- **`app/not-found.tsx`** — same visual; "We couldn't find that show." [Back to dashboard]

### Connectivity
- **Offline detection** — `navigator.onLine` + ping check every 30s. Banner across the
  top: "You're offline — changes will save when you reconnect." Editor stays usable
  (autosave queues; replays on reconnect).

---

## Dashboard

### Empty (no projects)
Hero illustration of a dark house. "No shows yet — create your first one in two
minutes." [+ Start a new show] (primary), [Try the demo song] (secondary, seeds
"Wizards in Winter").

### Loading
Skeleton: 6 project cards with shimmering thumbnail + title bar. Same grid shape as
real content — no layout shift.

### Error (DB unreachable)
"Couldn't load your shows." [Try again] (refetches), small "Still broken?" link to
support email.

---

## Editor

### Loading (project hydrate)
Skeleton with the editor's three regions visible (sidebar, timeline area, top bar).
Sidebar items show as placeholder rows; timeline is a flat striped placeholder; song
chip in top bar shows "Loading…" with a small spinner. ≤500ms for cached, ≤2s
typical.

### Empty (no audio yet)
Default tab is Audio Timeline. Without audio:
- Waveform area shows: musical-note illustration + "Drop an MP3 to begin" + dashed
  drop zone covering the waveform region. [Browse files] inline button.
- Tracks render with a subtle "no audio loaded" notice; effects can still be placed
  but the play button is disabled with tooltip "Add a song first."

### Empty (audio loaded, no effects)
"Drag an effect from the left, or let AI build a starter." [✦ Generate from music]
sits inline above the timeline.

### Loading (audio analysis)
Replace the waveform with a progress bar: "Analyzing… detecting beats…" and a counter
("142 beats so far"). Editor remains interactive — user can rename, place fixtures
in Layout tab, etc. Just no playback yet.

### Error (audio upload)
- File too large: "MP3s need to be under 30MB." [Choose another file]
- Unsupported format: "We support MP3, WAV, M4A, OGG. (Got: .flac)" [Choose another]
- Network failure: "Upload interrupted." [Retry] — resumes from last chunk if
  Supabase resumable uploads are enabled.

### Error (analysis failure)
"We couldn't analyze that song. You can still build manually — beats won't snap."
[Try a different file] [Continue without beats]. Logs to error monitoring; if it's
a known-bad audio (DRM-locked AAC etc), surface a specific message.

### Error (autosave failure)
Top bar save indicator goes red: "Couldn't save — last saved 2 min ago." Click for
details modal. Editor stays editable; on reconnect it tries again. After 3 failures,
prompt "Download a local backup" → exports current state as `.lumen.json`.

### Loading (preview render)
First render of a heavy effect (firework × multiple fixtures): show overlay "Rendering
preview…" with cancel. Fade out when first frame is ready.

### Error (preview crash)
Caught by an error boundary around the renderer. "Preview hit an error." [Switch to
SVG mode] [Reload editor]. Sequence is preserved (it's in Zustand, separate from the
preview tree).

---

## Layout tab

### Empty (no fixtures placed)
House SVG visible with a pulsing dashed outline around the roof + bushes + tree
spots. "Drag fixtures from the left to place them on your house." Inline shortcut:
"Or [auto-place all] for our recommendation."

### Empty (custom-uploaded house, no anchors)
"Custom houses don't have automatic anchor points — drag freely to place." No dashed
outlines.

### Error (custom SVG upload)
- Bigger than 1MB: "Custom house SVGs need to be under 1MB."
- Not an SVG: "Upload an SVG file (.svg)."
- Malformed SVG: "We couldn't parse that SVG. Try simplifying it in Figma or
  Illustrator." Falls back to default house.

---

## Preview tab

### Empty (no audio)
"Add a song to see your show in action." [Go to Audio tab]

### Empty (audio but no effects)
Mute, dimmed house. "No effects yet — your house will be dark."

### Error (mirror-to-lights — Bridge offline)
Inline banner: "Bridge is offline — preview will show on screen only." [Open Bridge]
(deep-link)

### Error (mirror-to-lights — controller dropped)
"Lost connection to Falcon F16v4." Lights on screen continue; the affected
controller's fixtures dim with a small warning icon.

---

## AI panel

### Empty (no actions run)
Five action cards visible. No chat history.

### Loading (generation in progress)
Progress steps animate in (per `08-ai-panel.md`'s mock spec). Cancel button always
reachable.

### Error (AI provider error)
"AI didn't respond. Try again, or build manually." [Retry] [Dismiss]. No partial
patches applied — patches only commit on `done` event.

### Error (AI returned invalid patch)
Caught at the zod boundary in the API route. Treated as provider error in the UI;
logged with full diagnostic for us.

---

## Export dialog

### Loading (export rendering)
Progress bar: "Building xLights file…" → "Encoding audio…" → "Done."
Cancel button always present.

### Error (export failure)
Specific by format:
- Lumen JSON: never fails (in-memory).
- xLights: "Couldn't generate the xLights file. Most likely cause: unmapped channels.
  [View channel map]"
- Video: "Recording stopped early — your browser ran out of memory. Try a shorter
  range or lower resolution."

---

## Hardware (Bridge / controllers)

### Empty (no Bridge installed)
Banner on dashboard: "Install Lumen Bridge to run live shows." [Get Bridge]
Settings → Hardware shows the install card prominently.

### Empty (Bridge installed, no controllers)
"No controllers yet. Bridge will scan your network." [Scan now] [Add manually]

### Loading (controller test)
Test button shows spinner; status pill shows "Sending test pattern…" for 3s.

### Error (controller offline)
Status pill turns gray. Click for details: "Last seen 12 minutes ago."
[Retry connection] [Edit settings] [Remove controller]

### Error (firewall / multicast blocked)
Detected when E1.31 discovery returns 0 devices but ping to the gateway succeeds.
"Your router seems to be blocking multicast — see [troubleshooting guide]."

---

## Auth (Clerk)

Clerk owns most of these visually, but our wrapper page provides:
- Loading: branded splash while Clerk hydrates.
- Error (invalid credentials): Clerk's default text, our visual treatment.
- Error (network): "Couldn't reach Lumen — check your connection."

---

## Onboarding

### Loading (between steps)
Step transitions with a 200ms slide; never a full reload.

### Error (Bridge pairing code wrong)
Inline below input: "That code expired or doesn't match. Check Bridge for a new one."

### Error (controller test failed during setup)
See Step 5 in `12-onboarding-hardware-setup.md`. Branched recovery, not a generic error.

---

## Settings

### Loading
Skeleton rows for each settings section.

### Error (save failure)
Inline banner above the section: "Couldn't save changes." [Retry] — does not blow
away the user's edits in the form.

---

## Acceptance

- [ ] Pull network cable mid-edit → offline banner appears, autosave queues, on
  reconnect everything saves
- [ ] Brand-new account on dashboard shows the empty state, not a loading skeleton
  forever
- [ ] Upload a 50MB MP3 → file-too-large error with clear next step
- [ ] Block multicast in router firewall → controller discovery surfaces the specific
  router-troubleshooting message, not a generic error
- [ ] Cause an autosave failure (kill API mid-request) → indicator goes red, user
  can keep working, reconnect resolves
- [ ] Force the AI provider to error → panel shows recoverable error, no orphan
  patches in undo history
