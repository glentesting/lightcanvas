# 18 — Telemetry, Analytics, Error Monitoring

What we instrument, how we collect it, what we don't collect, and how a bug
gets from a user's browser to a fix.

## Stack

- **Error monitoring:** Sentry (browser + Bridge + server)
- **Product analytics:** PostHog (events + funnels + sessions where opted in)
- **Performance:** Vercel Web Analytics (Core Web Vitals) + Sentry Performance
- **Logging:** Vercel runtime logs + Supabase logs (server-side)

All three accept self-hosted alternatives later if cost matters; the interfaces
below are vendor-agnostic.

---

## Privacy posture

- **Cookie banner** with explicit consent. Default to *off* for analytics
  (GDPR-safe). Error monitoring runs without consent because it's necessary for
  service reliability — disclose in the privacy policy.
- **No PII in events** — never include the song name, project name, audio URL, or
  controller IP in event payloads. Use IDs instead and resolve server-side when
  needed.
- **No raw audio uploaded to third parties.** Sentry breadcrumbs that mention audio
  files redact the filename to `<audio>`.
- Honor **Do Not Track** and PostHog's `respect_dnt` flag.
- Bridge: opt-in telemetry on first launch. Never default-on for a desktop app.

---

## Events to track (PostHog)

Group by funnel.

### Activation
- `signup_completed`
- `onboarding_step_view` `{ step }`
- `onboarding_completed` `{ track: 'designer' | 'operator' }`
- `bridge_paired`
- `controller_added` `{ kind, discoveryMethod }`
- `first_audio_uploaded` `{ duration, format }`
- `first_effect_added` `{ effectId }`
- `first_export` `{ format }`
- `first_show_run` `{ outcome }`

### Editor engagement
- `effect_added`, `effect_moved`, `effect_resized`, `effect_deleted`
- `ai_action_run` `{ action, vibe, intensity }`
- `ai_action_kept` `{ action, blocksAdded }` / `ai_action_undone`
- `preview_played`
- `mirror_to_lights_toggled`

### Reliability
- `autosave_failed` `{ reason }`
- `analysis_failed` `{ reason }`
- `export_failed` `{ format, reason }`
- `bridge_disconnected` `{ duration }`
- `controller_dropped_during_show` `{ kind }`
- `show_run_completed`, `show_run_failed`, `show_run_skipped`

### Commerce (when billing ships)
- `pricing_viewed`, `pricing_plan_clicked`
- `checkout_started`, `checkout_completed`, `checkout_abandoned`
- `subscription_canceled`

Each event auto-decorated with: `userId` (only if signed in), `sessionId`,
`platform`, `browserVersion`, `route`. No more.

---

## Error monitoring (Sentry)

### Browser
- Wrap app in `<Sentry.ErrorBoundary>` at the root
- One per major surface (editor, preview, AI panel) for finer fingerprinting
- Include user ID via `Sentry.setUser({ id })` after Clerk auth
- Tag events with `surface` (`landing | dashboard | editor | remote | settings`)
  and `feature` (`audio | layout | preview | ai | export | bridge`)
- `replaysSessionSampleRate: 0.0`, `replaysOnErrorSampleRate: 1.0` so we capture
  reproductions only when something breaks (privacy-friendly)
- Mask all inputs in replays; mask audio waveform canvas (could be identifying
  via timing patterns)

### Server
- Vercel + Sentry tracing for API routes
- Tag with `route`, `userId`, `projectId` when relevant
- Don't log request bodies for upload endpoints (audio data in transit)

### Bridge
- Sentry desktop SDK; uses the same DSN namespaced by environment
- Local crash reports queued offline if internet is down — flushed on reconnect
- Never include LAN IPs in stack traces; redact

---

## Logging

- Use the standard pattern `console.{level}` in dev; `pino` (or similar) wrapper
  in production
- Levels: trace / debug / info / warn / error
- Don't log autosaved payloads or AI prompts at `info` (PII risk)
- Errors logged at `error` automatically reach Sentry via integration

---

## Health checks

- `/api/health` — public, returns `{ ok: true, version, timestamp }`
- `/api/health/db` — protected, runs a SELECT 1 against Supabase
- Bridge → Cloud heartbeat at 2s already covers Bridge health

---

## Dashboards

Internal only. Set up in PostHog + Sentry:

- Activation funnel: signup → onboard → audio → first effect → export
- Editor engagement: avg effects per project, avg duration of editing session
- Reliability: error rate per surface, autosave failure rate, show-run success rate
- Performance: Core Web Vitals per surface

Review weekly. Threshold alerts:
- Error rate > 1% on any surface for 15 min → Slack #alerts
- Autosave fail rate > 0.5% sustained 1h → Slack
- Show-run failure rate > 5% during peak season (Dec) → page on-call

---

## Acceptance

- [ ] Sentry captures a deliberately thrown error from any surface; user ID + tags present
- [ ] PostHog events fire only after consent; revoking consent stops new events and clears the local queue
- [ ] No PII (song names, controller IPs, audio URLs) appears in Sentry breadcrumbs or PostHog payloads — verify with a network inspection during a real session
- [ ] Bridge captures a crash, queues it offline, sends it on reconnect
- [ ] Activation funnel renders with real data after a test user runs through signup → first export
- [ ] Lighthouse mobile audit on landing matches Web Vitals reported in production within 10%
