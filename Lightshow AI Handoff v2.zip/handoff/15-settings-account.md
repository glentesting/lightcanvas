# 15 — Settings, Account, Team, Billing Placeholder

The prototype shows a top-bar avatar but never opens it. This is the spec for what's
behind it. Built as nested routes under `/settings/*` so each panel deep-links and
persists state in URL.

## Information architecture

```
/settings              → redirect to /settings/account
/settings/account      → profile, email, password, sign-out, delete account
/settings/hardware     → Bridge installs, controllers, "run setup wizard"
/settings/audio        → audio library, storage usage, default analysis options
/settings/schedules    → list of show schedules, edit, run history
/settings/team         → (placeholder for v2 — see below)
/settings/billing      → (placeholder for paywall — see below)
/settings/integrations → xLights export defaults, future API keys
/settings/notifications → email/push preferences for show events
```

Left sidebar of `/settings` lists the sections; right pane is the active section.
On mobile, sections collapse to a vertical menu with chevrons.

---

## Account section

### Profile card
- Avatar (Clerk-managed, click to upload)
- Display name (inline editable)
- Email address (Clerk-managed)
- Account created date

### Security
- Change password → opens Clerk's hosted UI in an inline frame
- Two-factor auth → Clerk-managed
- Active sessions → list of devices currently signed in, with "Sign out" per row

### Sign out (everywhere)
Single button. Clerk session revoke + token rotate.

### Delete account
Destructive, gated:
1. Click "Delete account"
2. Modal: "This deletes everything — projects, audio, schedules, controllers."
3. Type the email address to confirm
4. 14-day soft-delete grace period (account marked `pending_deletion`, restorable
   from a "Reactivate" email)
5. After 14 days, hard delete: cascade DELETE all rows owned by this user, purge
   storage buckets prefixed with userId, mark Bridge installations as orphaned
6. Final email: "Your account is gone."

GDPR/CCPA-compliant by default. See `19-legal.md`.

---

## Hardware section

Just renders the relevant pieces of `11-hardware-bridge.md` and
`12-onboarding-hardware-setup.md`:
- Bridge installations (this and other devices), connection status, version
- "Update Bridge" button when a newer version is out
- Controllers list with status dots, edit/delete
- "Run hardware setup wizard" button

---

## Audio library

- List of all audio files the user has uploaded across all projects
- Per-row: filename, duration, BPM, projects using it, size
- Storage usage bar: used / quota (free tier: 500MB; paid: 10GB; placeholder)
- Bulk select → delete (warns if a file is used by a project)

This decouples audio files from projects. v1 hides this complexity (each project
has its own audio); v1.1 lets a single audio file be referenced by multiple projects.

## Schedules

List view of all show schedules the user has created. Per row:
- Project name, RRULE rendered as plain English ("Daily, 6:00pm–9:00pm, Dec 1–Jan 5"),
  status (active/paused), bridge that runs it.
- Click → schedule detail with run history (last 30 runs: status, duration,
  any failures, frames dropped).

## Team (placeholder, v2)

Renders a "Coming soon — share shows with family" empty card. Capture interest with
a "Notify me" button (writes to a `feature_interest` table). Don't build the
permission model yet.

## Billing (placeholder)

Per the user's directive: ignored for now, but the route exists with a placeholder.

```
"Lumen is free during early access. Billing options will appear here when we launch
paid tiers."
```

When billing ships, this page becomes:
- Current plan (Free / Hobbyist / Pro / Studio)
- Renewal date, last payment
- Upgrade / downgrade / cancel
- Invoice history

Stub the API: `/api/billing/portal` returns 501 Not Implemented for now. Don't
import Stripe yet.

## Integrations

- xLights export defaults — frame rate, default model naming, include audio file
- API keys (v2)
- Webhooks (v2)

## Notifications

For show events (failed run, controller dropped, schedule starting in 5 min):
- Email — checkboxes per event type
- Push (PWA) — opt-in, triggers `Notification.requestPermission()` first
- "Quiet hours" — don't send between X:XX and Y:YY

---

## Acceptance

- [ ] User can change their name and avatar; updates show across the app within seconds
- [ ] Sign out clears the session in all tabs of the same browser
- [ ] Delete account flow requires typed-email confirmation; account becomes
  unreachable after deletion; user receives confirmation email
- [ ] Storage usage bar reflects actual Supabase Storage usage for that user
- [ ] Schedule detail shows real run records (from the `show_runs` table in 11)
- [ ] Billing page exists at `/settings/billing` with the placeholder copy and no
  Stripe imports
- [ ] All settings sections respond cleanly on mobile (≥ 360px wide)
