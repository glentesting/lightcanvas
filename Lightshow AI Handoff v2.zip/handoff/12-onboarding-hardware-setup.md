# 12 — Onboarding & Hardware Setup Wizard

The original `02-projects-and-dashboard.md` describes a 3-step onboarding (decoration
target / light count / optional audio). That covers the *creative* side. This file
covers the *physical* side — the part that's hardest in real product, and that the
prototype glossed.

---

## Two onboarding tracks

We branch in step 1:

```
"How are you running this show?"
[ ] Just designing — I'll export to xLights or another tool   → Designer track
[ ] I want Lumen to drive my actual lights                    → Operator track
[ ] I'm not sure yet                                          → Designer track + nudge later
```

**Designer track** = current onboarding (creative steps only). Skip everything below.

**Operator track** adds the hardware setup wizard described here, *after* the creative
steps. The user can also re-enter this wizard later from Settings → Hardware.

---

## Operator wizard — 6 steps

### Step 1 — Install Lumen Bridge

Cards for macOS / Windows / Linux. "Download Bridge" — direct download from
`releases.lumen.app/bridge/{version}/{platform}`.

After download, instructions: "Open Bridge, then come back here." A live status pill
(`Waiting for Bridge…`) updates to `Bridge connected ✓` once Bridge phones home.

If the user has multiple computers, "Run Bridge on my [Garage PC / Living Room Mac /
…]" — they pick which machine should be the canonical one. We support multiple
Bridges per account but one schedule runs on one Bridge.

**Skip option:** "I'll set up Bridge later" — saves their progress, takes them to
the dashboard with a yellow banner: "Hardware setup incomplete — finish to run live
shows."

### Step 2 — Pair Bridge to your account

Bridge shows a 6-digit code. User pastes it into the web wizard. Cloud verifies
and binds Bridge instance to user. Same flow as `gh auth login` device-code OAuth.

### Step 3 — Discover controllers

Bridge auto-scans the LAN. Wizard shows a live list:

- mDNS results (WLEDs and friendly devices announce themselves)
- Generic E1.31 devices that respond to a discovery ping
- "Couldn't find your controller? Add manually" → fields: Name, Kind dropdown
  (Falcon F16v4, Pixlite 16, AlphaPix 16, WLED, Other E1.31, Other DDP, Other Art-Net),
  IP address, Universe range.

For each found controller: Name (editable), IP, model (auto-detected for WLED, manual
for the rest), "Use this controller" toggle.

**Failure path:** "We couldn't find any controllers." Show troubleshooting checklist:
- Is the controller powered on?
- Is it on the same Wi-Fi as Bridge? (we show Bridge's network)
- Is multicast allowed on your router? (link to a docs page)
- Try adding manually with the IP from your controller's web UI.

### Step 4 — Map fixtures to controllers

The wizard pre-loads the user's pre-placed default fixtures (the 6-fixture starter
pack). For each, a row:

```
Roofline strip · 220 pixels      Controller [Garage WLED ▾]  Universe [1]  Start ch [1]
Mega tree · 480 pixels           Controller [Falcon F16 ▾]   Universe [3]  Start ch [1]
…
```

We auto-allocate channels (continuing where the previous fixture ended, jumping to
universe+1 when overflowing 512). User can override.

Inline validation:
- Red badge if channels overlap within a universe
- Red badge if `startChannel + pixelCount * 3 > 512` and we'd silently span universes
  (require confirmation: "This fixture will span universes 3 and 4 — that's fine if
  your controller is configured for both.")

### Step 5 — Test fixtures

For each fixture, a "Test" button. Bridge sends a 3-second rainbow chase down the
strand. Wizard asks:

```
Did the lights run a rainbow chase along your roofline?
[ Yes — looks right ]   [ Wrong fixture lit up ]   [ Backwards direction ]   [ Nothing happened ]
```

Branches:
- **Wrong fixture:** likely a channel-mapping mistake — opens the previous step
  pre-focused on the wrong fixture.
- **Backwards:** flip the `reversed` flag and re-test.
- **Nothing:** controller-level failure — show controller's status, refresh, and
  link to troubleshooting (firewall blocking E1.31 multicast is the #1 cause).

### Step 6 — Schedule your first show

Optional. Pre-fill: "Wizards in Winter, every day Dec 1 – Jan 5, 6:00pm – 9:30pm,
loop." User can edit or skip.

---

## Visual spec

- Match the prototype's onboarding visuals: warm cream surface, big illustrative
  step indicator, primary action right-aligned, "Skip for now" left-aligned ghost.
- Each step is a separate route under `/onboarding/hardware/[step]` so refresh keeps
  position. State persists in Clerk `publicMetadata.hardwareSetup` between steps.
- Top-right "Save and exit" → returns to dashboard with the in-progress banner.

---

## Re-entering the wizard

Settings → Hardware → "Run setup wizard." Same flow, but pre-fills everything from
existing config — useful when:
- User adds a new controller (skip to step 3)
- User re-tests after a wiring change (skip to step 5)
- User upgrades Bridge to a new computer (skip to step 1, but keep mapping)

---

## Deep-link from desktop Bridge

Bridge's first-run UI shows: "Open lumen.app to finish setup" → opens
`lumen.app/onboarding/hardware?bridge_id=...&device_code=...` directly to step 2 with
the code pre-filled. This eliminates the most error-prone copy-paste.

---

## Acceptance

- [ ] New user picks "I'll just design" — never sees hardware wizard, lands on dashboard
- [ ] New user picks "I want Lumen to drive my lights" — completes steps 1–5, can run a Test on a real (or mock) controller
- [ ] Bridge installation flow works on macOS, Windows; Linux is a download but no notarization
- [ ] User completes wizard, signs out, signs in on a new browser — hardware state persists (cloud-side, not browser-local)
- [ ] User adds a second controller from Settings → Hardware — re-enters wizard at step 3 with existing state intact
- [ ] If Bridge is uninstalled / loses internet, the dashboard banner returns and the wizard re-prompts
