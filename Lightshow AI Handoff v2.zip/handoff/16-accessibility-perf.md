# 16 — Accessibility & Performance Gating

The prototype emphasizes warmth and motion; the production app must be reachable for
people on slow phones, vestibular sensitivities, screen readers, and keyboard-only
input. None of these are optional.

## Accessibility

### Standards
Target **WCAG 2.2 AA** for the entire app. **AAA** for critical flows (auth, panic
stop, billing, delete account). Don't ship a feature without an a11y review.

### Color & contrast
- Body text on `--bg`: 7:1 minimum (AAA where it costs nothing)
- UI text on panels: 4.5:1 minimum
- Effect-color chips have decorative use only — never communicate state purely with
  color. Always pair with an icon + text.
- The dark editor preview area is borderline today; bump body text contrast on
  selected blocks and the playhead.

### Focus visibility
- Every interactive element gets a 2px `outline-accent` ring on `:focus-visible`
- Custom controls (timeline blocks, fixture pills, the playhead) wire `tabindex` and
  arrow-key navigation. Don't rely on mouse-only.
- Skip-to-content link at top of every screen.

### Keyboard parity
- Every action available by mouse must have a keyboard equivalent:
  - Drag from palette → tab to chip, Enter to "pick", tab to track, Enter to drop
  - Resize block → with block focused, `[` and `]` shrink/grow by one beat
  - Move block between tracks → `Cmd+Up/Down`
  - Multi-select → Shift + arrow keys
- Shortcut help screen reachable via `?`

### Screen reader
- Every fixture, block, and effect has an accessible name.
  Block aria: `"Twinkle, on Roofline, from 0:12 to 0:18"`
- Playhead announces time on movement, throttled to once per second.
- Live region for transport state ("Playing", "Paused", "Stopped at 0:42").
- AI panel events announce as polite live region updates.

### Motion
- Honor `prefers-reduced-motion`:
  - Marketing hero: drop the animated lights, swap to a static SVG
  - Editor playhead: no smooth scroll, snap to position
  - Transitions: fade only, no slides or scales > 1.05
  - Toast/notification slides: fade
- A "Reduce motion in preview" user setting (Settings → Notifications? — actually
  put it in Account → Accessibility) overrides preview's animation density even when
  the OS doesn't request it. Some users want lush previews on monitor, calm previews
  on a tablet they hand to a kid.

### Touch
Covered in `14-mobile-responsive.md`; min 44×44pt hit targets.

---

## Performance

### Budgets
| Surface | LCP | TBT | INP | Bundle (gzip) |
|---|---|---|---|---|
| Marketing landing | ≤ 2.5s | ≤ 200ms | ≤ 200ms | ≤ 120 KB |
| Dashboard | ≤ 2.5s | ≤ 200ms | ≤ 200ms | ≤ 200 KB |
| Editor | ≤ 4.0s (one-time, OK) | ≤ 400ms | ≤ 200ms | ≤ 600 KB |
| Show Remote | ≤ 2.0s | ≤ 200ms | ≤ 100ms | ≤ 150 KB |

Run Lighthouse CI in GitHub Actions. Fail the build on regression > 10%.

### Marketing hero
- The animated house SVG runs a single `requestAnimationFrame` loop. Wrap it in:
  - `IntersectionObserver` — pause when off-screen
  - `prefers-reduced-motion` — render a static "snapshot" SVG instead
  - `document.visibilityState` — pause when tab is hidden
  - On `<lg` breakpoints, render the static snapshot regardless (saves CPU on phones)
- Provide a static-SVG fallback path that's the first paint, then upgrade to animated.

### Editor
- Lazy-load WaveSurfer + Meyda only when a project has audio.
- Lazy-load the canvas-fancy renderer only when the user toggles it on.
- Code-split per tab: Audio Timeline, Layout, Preview each load independently.
- Web Worker for beat detection (already in `04-audio-engine.md`); keep main thread
  free during analysis.
- Effect computation under 16ms/frame for ≤3000 pixels @ 30fps; benchmark in CI.

### Bridge link
- Mirror-to-lights uses a simple delta WebSocket payload, not full frame dumps.
- Idle Bridge sends one heartbeat every 2s, not 30fps of "no-op."

### Bundle hygiene
- Tree-shake lucide-react via per-icon imports.
- Import only used shadcn primitives.
- No moment.js — use `date-fns` or native `Intl`.
- No lodash globals — per-function imports.

---

## Acceptance

- [ ] axe DevTools clean on every screen
- [ ] Tab through the entire editor with eyes closed (mentally) — every action reachable
- [ ] VoiceOver / NVDA: name + role + state announced for every custom control
- [ ] `prefers-reduced-motion: reduce` set in OS → marketing hero is static, editor
  has no slides, preview animations honor the override
- [ ] Lighthouse mobile ≥ 90 on landing, dashboard, remote
- [ ] Lighthouse desktop ≥ 95 on editor (first nav)
- [ ] Editor 30fps preview with 5000 pixels does not drop frames on a 2019 MacBook Air
- [ ] Bundle budgets hold; CI fails on regression
