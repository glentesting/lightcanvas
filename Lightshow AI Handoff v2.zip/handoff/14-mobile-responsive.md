# 14 — Mobile & Responsive

The editor is desktop-first and that's correct — timeline DnD needs precision.
But several surfaces must work on mobile, and one of them (the Show Remote) is the
single most-used screen during a show season.

## Surface-by-surface posture

| Surface | Mobile posture |
|---|---|
| Marketing landing | **Full responsive** — primary path |
| Sign-in / sign-up | **Full responsive** — Clerk handles, we restyle |
| Onboarding | **Full responsive** — most users finish on phone |
| Dashboard | **Full responsive** — read-only-ish; create/rename/delete works |
| Editor | **Read-only viewer + redirect** — see below |
| Preview tab | **Full responsive viewer** (no edit) |
| Show Remote | **Mobile-first** — purpose-built for phone |
| Settings | **Full responsive** |

---

## Breakpoints

```
sm:  ≥ 640px    phones (large)
md:  ≥ 768px    tablet portrait
lg:  ≥ 1024px   tablet landscape / small laptop
xl:  ≥ 1280px   laptop
2xl: ≥ 1536px   desktop
```

The editor proper requires `lg`. Below that we redirect (see below).

---

## Marketing landing — responsive rules

- Hero stacks vertically on `<lg`. Animated house illustration scales but keeps its
  aspect ratio. Its complex animation reduces under `prefers-reduced-motion` and
  pauses entirely when off-screen (see `16-accessibility-perf.md`).
- Pricing cards stack 1-up on `<md`, 2-up on `md`, 4-up on `lg+`.
- Comparison table collapses to an accordion (one row per row of the table) on `<md`.
- Sticky CTA bar appears at the bottom of viewport on `<md` after the user scrolls
  past the hero.

## Auth, dashboard — straightforward responsive

- Top bar collapses search behind a magnifying glass on `<md`.
- Project grid: 1-up phone, 2-up `md`, 3-up `lg+`.
- New-project dialog → bottom sheet on `<md`, modal on `md+`.

## Onboarding — mobile-first review

- Step indicator becomes a horizontal pip row.
- Sliders enlarge to a min-height of 56px to accommodate touch.
- File picker uses native picker (which on mobile lets users pick from cloud, not
  just local files).

---

## Editor on mobile — block + redirect

```
"Lumen's editor needs a bigger screen."
Visual: small phone with a dimmed editor screenshot.
Text: "Open this on a laptop or tablet to edit. You can still preview your show
       and run the remote from here."
Buttons: [Open Preview] [Open Show Remote] [Email me a link to open later]
```

The "email me a link" sends a one-time deep-link to the user's email
(`mailto:` is fine) so they can resume on desktop.

We do **not** ship a mobile editor in v1. Touch + timeline editing is a v3+ effort.

## Preview on mobile — full-screen viewer

`/projects/[id]/preview` is a separate route (different from `/edit?tab=preview`)
that's mobile-friendly:
- House SVG fills viewport, 16:9 letterboxed.
- Bottom transport bar: play/pause, scrub, song title.
- "Send to lights" toggle if Bridge is online.
- No tabs, no sidebar, no edit affordances.

Used both standalone and embedded by the Show Remote.

---

## Show Remote — mobile-first

`/remote` (PWA-installable). The Christmas-eve, on-the-front-lawn, glove-on-cold-fingers
use case.

### Layout (portrait, single column)
1. **Status header** — Bridge online · Controllers all green · Time
2. **Now playing** card — album-art-style square (project thumbnail), song title,
   transport. Big play / pause button (88×88pt — no fat-finger problems).
3. **Up next** — list of upcoming scheduled runs with countdown. Swipe to skip.
4. **Quick actions** — All on / All off / Pause schedule / Resume
5. **Per-controller status** — collapsed by default; expand to see fixture-level
   detail and "Test" buttons.

### Behaviors
- Stays awake while showing (`screen-wake-lock` API where available).
- Polls Bridge status every 2s via SSE; gracefully degrades to 10s polling.
- Push notifications (PWA) for show-failed events.
- One-tap **Panic stop** — bottom of screen, requires long-press 1s to fire (avoids
  accidental stops). Sends `stop-everything` to Bridge.

### Visual
- Same warm-light aesthetic as the rest of the app — but optimized for outdoor
  visibility (slightly higher contrast, larger touch targets, no thin strokes).
- Optional **Dark stage mode** toggle: switches the remote — only the remote — to
  a high-contrast dark theme so it doesn't ruin night vision while operating the
  show in the dark. (Single exception to the "no dark mode" rule.)

---

## Touch & gesture rules

- Min hit target 44×44pt everywhere.
- No hover-only affordances on any surface that might be touched.
- Long-press for destructive (panic stop, delete schedule run).
- Swipe-to-dismiss on cards in lists; never swipe-to-delete without a confirm.

---

## PWA manifest

```json
{
  "name": "Lumen",
  "short_name": "Lumen",
  "start_url": "/dashboard",
  "display": "standalone",
  "background_color": "#fbfaf6",
  "theme_color": "#fbfaf6",
  "icons": [/* 192, 512, maskable */]
}
```

The remote (`/remote`) is the install target — show an "Add to Home Screen" hint
banner the first time the user visits it on mobile.

---

## Acceptance

- [ ] Lighthouse mobile audit ≥ 90 on landing, dashboard, remote
- [ ] Editor on a 360px-wide screen shows the redirect page, no horizontal scroll
- [ ] Show Remote: on a real phone, every interactive element is reachable with one
  thumb (test in portrait)
- [ ] Panic stop requires intentional long-press; one tap doesn't fire it
- [ ] PWA installable on iOS Safari and Android Chrome
- [ ] Wake lock keeps the remote on for 30+ minutes during a show without dimming
